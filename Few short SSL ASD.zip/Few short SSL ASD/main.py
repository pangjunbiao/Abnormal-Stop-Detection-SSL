import torch
import numpy as np
import random
from models.gcn.gcn_model import GCNWithSegments, train_segment_aware_gcn, evaluate_gcn_predictions_ap_auc
from models.gcn.graphsage_model import train_graphsage, GraphSAGEMean
from models.gcn.self_training import run_self_training, evaluate_and_plot_ST
from models.gcn.sgc_model import train_sgc, SGCWithSegments
from utils.evaluate_indicators import evaluate_indicators
from models.graph.feature_embedding import embed_node_features, calculate_features, apply_confidence_weights
from models.graph.SAGE_segmentation import segment_road_by_distance_and_time, summarize_segments, segment_fixed_length
from models.graph.graph_utils import build_adaptive_graph, apply_ltiga_adjustment
from utils.data_preprocessing import preprocess_data
from utils.label_propagation import run_label_propagation
from utils.plot_abnormal_vs_groundtruth import plot_and_save_distances
from utils.save_abnormal_nodes_after_self_training import save_abnormal_nodes_after_self_training
from utils.segment_visualize import visualize_segment_summary
from utils.save_abnormal_stops import save_abnormal_stops_after_self_training
from utils.verify_abnormal_nodes_and_segments import verify_abnormal_nodes_and_segments
from visualizations.plot_distance_distribution import plot_matched_abnormal_stops_with_distances
from visualizations.plot_node_embeddings_tsne_pca import plot_node_embeddings_tsne_pca
from visualizations.plot_prediction_confidence_histogram import plot_prediction_confidence_histogram
from visualizations.plot_segment_abnormality import plot_segment_abnormality_scores
from visualizations.plot_tsne_comparison import plot_tsne_true_vs_pred
from collections import Counter
from visualizations.visualize_indicator_scores import plot_auc_ap_scores
from visualizations.visualize_abnormal_vs_true_stops import visualize_abnormal_vs_true_stops
import argparse
import os
import csv
from datetime import datetime
from models.gcn.baseline_dgi import DGI_GCN_Baseline, pretrain_dgi, finetune_dgi_gcn
from models.gcn.baseline_markov_lr import (
        MarkovLogReg, train_markov_lr, evaluate_markov_lr_ap_auc, build_order_from_segment_time
    )



# #Function to set random seed
# Function to set random seed
def set_random_seed(seed=42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--seed", type=int, default=42,
                        help="Random seed for the whole run")
    parser.add_argument("--trial_id", type=str, default="",
                        help="Optional trial identifier (e.g., run_01)")
    parser.add_argument("--metrics_csv", type=str,
                        default="./data/results/trial_metrics.csv",
                        help="Where to append per-trial metrics")
    return parser.parse_args()


args = parse_args()
set_random_seed(args.seed)

def append_metrics(csv_path, trial_id, seed, setting, auc, ap):
    os.makedirs(os.path.dirname(csv_path), exist_ok=True)
    file_exists = os.path.isfile(csv_path)

    with open(csv_path, "a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=["timestamp", "trial_id", "seed", "setting", "auc", "ap"]
        )
        if not file_exists:
            writer.writeheader()

        writer.writerow({
            "timestamp": datetime.now().isoformat(timespec="seconds"),
            "trial_id": trial_id if trial_id else f"seed_{seed}",
            "seed": seed,
            "setting": setting,
            "auc": float(auc),
            "ap": float(ap),
        })


def main():
    # Define paths
    raw_data_dir = "./data/raw_data"
    processed_data_path = "./data/processed_data/processed_data.csv"
    skipped_data_path = "./data/processed_data/skipped_rows.csv"
    node_features_raw_path = "./data/processed_data/node_features_raw.csv"
    node_features_ltiga_path= "./data/processed_data/node_features_ltiga.csv"
    plot_output_dir = "./data/results"
    results_output_path = "./data/processed_data/segment_results.csv"
    output_path= "./data/results/abnormal_predictions.csv"
    output_path_abnormal= "./data/results/abnormal_segments_final.csv"
    output_path_abnormal_node= "./data/results/abnormal_nodes_after_st.csv"
    output_path_groundtruth_predicted_distances= "./data/results/groundtruth_predicted_distances.csv"

    # True stop coordinates (from professor's code)
    true_GPS = np.array([
        [116.302661, 39.880903],
        [116.310097, 39.897319],
        [116.310297, 39.925278],
        [116.310304, 39.938717],
        [116.309811, 39.943409],
        [116.309557, 39.953169],
        [116.313866, 39.964449],
        [116.380633, 39.981016],
        [116.366219, 40.007226],
        [116.362843, 40.011537]
    ])

    # Step 1: Data Preparation
    print("Loading and preprocessing raw GPS data...")
    processed_data = preprocess_data(raw_data_dir, processed_data_path, skipped_data_path, true_GPS)

    print("Processed data saved at:", processed_data_path)

    # ============================================
    # Choose segmentation strategy (SAS or Fixed)
    use_sas = True  # Set to False to use fixed-length segmentation instead
    # ============================================

    # Step 2: Segment the road
    if use_sas:
        print("Segmenting road using Sparsity-Aware Segmentation (SAS)...")
        segmented_data = segment_road_by_distance_and_time(
            processed_data,
            adaptive=True,
            alpha=1.0,
            beta=1.0
        )
    else:
        print("Segmenting road using Fixed-Length Segmentation...")
        segmented_data = segment_fixed_length(
            processed_data,
            fixed_length_km=2.0  # Change this value as needed
        )

    # Summarize segments
    print("Summarizing segments...")
    segment_summary = summarize_segments(segmented_data)

    # Count pseudo-labels
    label_counts = segmented_data['pseudo_label'].value_counts().sort_index()
    print("🔍 Pseudo-label distribution:")
    for label in [-1, 0, 1]:
        print(f"Label {label}: {label_counts.get(label, 0)}")

    # Compute segment summary for visualization
    segment_summary = segmented_data.groupby('segment_id').agg({
        'distance_from_start': lambda x: x.max() - x.min(),
        'stay_time': 'sum'
    }).rename(columns={
        'distance_from_start': 'segment_length_km',
        'stay_time': 'total_stop_duration_sec'
    }).reset_index()

    print("📊 Segment summary preview:")
    print(segment_summary.head())

    # Segment visualization (SAS-aware)
    visualize_segment_summary(segment_summary, use_sas=use_sas)

    # ============================================
    # Choose whether to apply LTIGA (Set True/False)
    use_ltiga = True

    # Toggle to include/exclude inverse normalization (Eq. 18)
    apply_inverse_norm = True  # Set False to ablate Eq. (18)
    # ============================================

    # Step 3: Calculate indicators before LTIGA (no confidence weighting)
    print("Calculating indicators BEFORE LTIGA (unweighted)...")
    before_ltiga_data = calculate_features(segmented_data.copy(), use_weighted_confidence=False)
    embed_node_features(before_ltiga_data, output_file_path=node_features_raw_path)

    print("🔍 Evaluating indicators BEFORE LTIGA...")
    evaluate_indicators(
        before_data=before_ltiga_data,
        after_data=None,
        true_labels=before_ltiga_data["pseudo_label"],
        use_weighted_confidence=False
    )

    # Visualize BEFORE LTIGA
    plot_auc_ap_scores(
        data=before_ltiga_data,
        true_labels=before_ltiga_data["pseudo_label"],
        metrics=["TIS", "MSD", "TTA@k"],
        title_suffix="Before LTIGA",
        use_weighted=False,
        save_path=f"{plot_output_dir}/before_ltiga_auc_ap.png"
    )

    # Conditional Branch: With or Without LTIGA
    if use_ltiga:
        # Step 4: Apply LTIGA to adjust indicators in sparse segments
        print(f"Applying LTIGA to smooth unweighted indicators (inverse_norm={apply_inverse_norm})...")
        # after_ltiga_data = apply_ltiga_adjustment(
        #     before_ltiga_data.copy(),
        #     apply_inverse_norm=apply_inverse_norm  # NEW FLAG
        # )
        after_ltiga_data = apply_ltiga_adjustment(
            before_ltiga_data.copy(),
            k=5,  # keep fixed for SAS sensitivity
            sigma=0.3,
            use_gaussian=True,
            apply_inverse_norm=apply_inverse_norm
        )

        # Step 5: Recalculate confidence-weighted indicators AFTER LTIGA
        after_ltiga_data = apply_confidence_weights(after_ltiga_data)
        embed_node_features(after_ltiga_data, output_file_path=node_features_ltiga_path)

        # Step 6: Evaluate after LTIGA
        print("🔍 Evaluating indicators AFTER LTIGA...")
        evaluate_indicators(
            before_data=before_ltiga_data,
            after_data=after_ltiga_data,
            true_labels=after_ltiga_data["pseudo_label"],
            use_weighted_confidence=True
        )

        # Step 7: Visualize AFTER LTIGA
        plot_auc_ap_scores(
            data=after_ltiga_data,
            true_labels=after_ltiga_data["pseudo_label"],
            metrics=["TIS", "MSD", "TTA@k"],
            title_suffix="After LTIGA",
            use_weighted=True,
            save_path=f"{plot_output_dir}/after_ltiga_auc_ap.png"
        )
    else:
        # ⛔ LTIGA is skipped for ablation experiment
        print("⛔ LTIGA is skipped for ablation experiment.")
        after_ltiga_data = apply_confidence_weights(before_ltiga_data.copy())
        embed_node_features(after_ltiga_data, output_file_path=node_features_ltiga_path)

        print("🔍 Evaluating indicators AFTER confidence weighting (w/o LTIGA)...")
        evaluate_indicators(
            before_data=before_ltiga_data,
            after_data=after_ltiga_data,
            true_labels=after_ltiga_data["pseudo_label"],
            use_weighted_confidence=True
        )

        plot_auc_ap_scores(
            data=after_ltiga_data,
            true_labels=after_ltiga_data["pseudo_label"],
            metrics=["TIS", "MSD", "TTA@k"],
            title_suffix="After Confidence Only",
            use_weighted=True,
            save_path=f"{plot_output_dir}/after_conf_only_auc_ap.png"
        )

    # Step 8: Construct Graph using post-indicator data
    print("Constructing the graph{}...".format(" (with LTIGA)" if use_ltiga else " (w/o LTIGA)"))
    graph_data = build_adaptive_graph(after_ltiga_data)
    print(f"\u2705 Graph constructed with {graph_data.x.size(0)} nodes and {graph_data.edge_index.size(1)} edges.")

    # 📌 Save original labels before any propagation
    graph_data.original_y = graph_data.y.clone()  # Backup of original labels

    # Step 9: Label Propagation
    print("🔁 Running label propagation...")
    label_mask_before = (graph_data.y != -1).clone()  # Track initially labeled nodes
    refined_labels = run_label_propagation(graph_data)

    # Assign propagated labels
    graph_data.y = refined_labels

    # Fix NaNs
    print("Fixing any NaN values in node features before GCN...")
    graph_data.x = torch.nan_to_num(graph_data.x, nan=0.0, posinf=1.0, neginf=-1.0)

    # Step 10: Initializing GCN
    print("Initializing and training the GCN model...")
    input_dim = graph_data.x.size(1)
    hidden_dim = 64  # updated
    output_dim = 2
    segment_ids = graph_data.segment_id

    model = GCNWithSegments(input_dim=input_dim, hidden_dim=hidden_dim, output_dim=output_dim, num_layers=3)

    trained_model = train_segment_aware_gcn(
        model, graph_data, segment_ids,
        epochs=300, learning_rate=0.001, lambda1=0.0005, lambda2=0.0005
    )

    # Predict
    probs = trained_model.get_probabilities(graph_data)
    # ✅ Correct logic: low probability → abnormal (0), high probability → normal (1)
    predictions = (probs >= 0.26).long().cpu().numpy()
    print("GCN predicted label counts:", Counter(predictions))

    print("Initial training completed.")

    verify_abnormal_nodes_and_segments(graph_data, probs=probs, threshold=0.26)

    # Evaluate
    print("Evaluating GCN performance after self-training...")
    # evaluate_gcn_predictions_ap_auc(trained_model, graph_data)

    auc_gcn, ap_gcn = evaluate_gcn_predictions_ap_auc(trained_model, graph_data)
    append_metrics(args.metrics_csv, args.trial_id, args.seed, "GCN", auc_gcn, ap_gcn)

    # ✅ Self-Training Refinement
    print("Applying self-training for confident pseudo-label refinement...")
    graph_data = run_self_training(model, graph_data, threshold=0.775, max_new_labels=180, balance_labels=True)


    # 🔁 Retrain GCN using propagated labels
    print("Retraining the GCN on propagated labels...")
    model = GCNWithSegments(input_dim=input_dim, hidden_dim=hidden_dim, output_dim=output_dim)
    trained_model = train_segment_aware_gcn(
        model, graph_data, segment_ids,
        epochs=230, learning_rate=0.001, lambda1=0.001, lambda2=0.001
    )

    print("Retraining completed.")

    # Predict
    probs = trained_model.get_probabilities(graph_data)
    # ✅ Correct logic: low probability → abnormal (0), high probability → normal (1)
    predictions = (probs >= 0.26).long().cpu().numpy()
    print("ST predicted label counts:", Counter(predictions))

    # ✅ Evaluate GCN performance after self-training
    print("Evaluating GCN performance after self-training...")
    # results_after_self_training = evaluate_and_plot_ST(trained_model, graph_data, label="GCN + Self-Training")

    auc_st, ap_st = evaluate_and_plot_ST(trained_model, graph_data, label="GCN + Self-Training")
    append_metrics(args.metrics_csv, args.trial_id, args.seed, "GCN+ST", auc_st, ap_st)

    # print(f"AUC after self-training: {results_after_self_training['ST_AUC']}")
    # print(f"AP after self-training: {results_after_self_training['ST_AP']}")

    # After plot_segment_abnormality_scores:
    plot_segment_abnormality_scores(trained_model, graph_data, segment_ids, top_n=160)

    # verify abnormal stop nodes and segments
    verify_abnormal_nodes_and_segments(graph_data, probs=probs, threshold=0.26)

    save_abnormal_stops_after_self_training(
        model=trained_model,  # model after ST or GCN
        graph_data=graph_data,  # current graph data
        segmented_data_with_gps=after_ltiga_data,  # your segmented GPS dataframe
        output_path=output_path_abnormal,
        threshold=0.26  # Same threshold you used during prediction
    )

    save_abnormal_nodes_after_self_training(
        model=trained_model,
        graph_data=graph_data,
        output_path=output_path_abnormal_node,
        threshold=0.26
    )

    plot_and_save_distances(
        predicted_abnormal_csv=output_path_abnormal,
        ground_truth_coords=true_GPS,
        save_plot_path="./data/results/abnormal_vs_groundtruth_overlay.png",
        save_distance_csv=output_path_groundtruth_predicted_distances
    )

    # 📈 Plot matched stops with distances
    plot_matched_abnormal_stops_with_distances(
        predicted_csv=output_path_abnormal,   # Your predicted abnormal stops file
        true_gps_array=true_GPS,                                       # From memory
        save_path="./data/results/matched_stops_with_distances.png"
    )
    # # Visualize node embeddings
    # plot_node_embeddings_tsne_pca(trained_model, graph_data, method="tsne")


    # #side-by-side comparison of true vs. predicted labels
    # plot_tsne_true_vs_pred(trained_model, graph_data)

    # histogram
    plot_prediction_confidence_histogram(trained_model, graph_data)

    # ============================
    # Baseline SSL #1: SGC
    # ============================
    print("Initializing and training the SGC baseline...")
    sgc_model = SGCWithSegments(
        input_dim=graph_data.x.size(1),
        output_dim=2,
        K=2,            # typical SGC choice; safe baseline
        dropout=0.0
    )

    sgc_model = train_sgc(
        sgc_model,
        graph_data,
        epochs=200,
        learning_rate=0.01,
        weight_decay=5e-4
    )

    print("Evaluating SGC performance...")
    auc_sgc, ap_sgc = evaluate_gcn_predictions_ap_auc(sgc_model, graph_data, setting="SGC")
    append_metrics(args.metrics_csv, args.trial_id, args.seed, "SGC", auc_sgc, ap_sgc)

    # ============================================================
    # Baseline 2: GraphSAGE (mean) — run BEFORE your proposed GCN/ST
    # ============================================================
    print("\n==============================")
    print("Running baseline: GraphSAGE (mean)")
    print("==============================")

    input_dim = graph_data.x.size(1)

    sage_model = GraphSAGEMean(
        input_dim=input_dim,
        hidden_dim=64,
        output_dim=2,
        num_layers=2,  # keep simple baseline
        dropout=0.5
    )

    sage_model = train_graphsage(
        sage_model,
        graph_data,
        epochs=200,
        learning_rate=0.001,
        weight_decay=5e-4
    )

    # Evaluate with your existing evaluator (it uses model.get_probabilities)
    auc_sage, ap_sage = evaluate_gcn_predictions_ap_auc(
        sage_model, graph_data,
        setting="GraphSAGE(mean)"
    )

    append_metrics(args.metrics_csv, args.trial_id, args.seed, "GraphSAGE(mean)", auc_sage, ap_sage)

    # ============================
    # Baseline SSL #2: DGI pretrain + GCN finetune
    # ============================

    print("Initializing DGI+GCN baseline...")

    dgi_gcn_model = DGI_GCN_Baseline(
        input_dim=graph_data.x.size(1),
        hidden_dim=64,  # choose like your GCN hidden_dim
        output_dim=2,
        num_layers=2,  # encoder depth for embeddings
        dropout=0.5
    ).to(graph_data.x.device)

    print("🔁 DGI pretraining (self-supervised) ...")
    # Pretrain only the encoder, then put it back into the full model
    pretrained_encoder = pretrain_dgi(
        encoder=dgi_gcn_model.encoder,
        graph_data=graph_data,
        hidden_dim=64,
        epochs=200,
        lr=1e-3,
        weight_decay=0.0
    )
    dgi_gcn_model.encoder.load_state_dict(pretrained_encoder.state_dict())

    print("🎯 Finetuning DGI-pretrained encoder with supervised loss ...")
    dgi_gcn_model = finetune_dgi_gcn(
        dgi_gcn_model,
        graph_data,
        epochs=200,
        lr=1e-3,
        weight_decay=5e-4
    )

    print("Evaluating DGI+GCN performance...")
    auc_dgi, ap_dgi = evaluate_gcn_predictions_ap_auc(dgi_gcn_model, graph_data, setting="DGI+GCN")
    append_metrics(args.metrics_csv, args.trial_id, args.seed, "DGI+GCN", auc_dgi, ap_dgi)

    # ============================
    # Baseline: Probabilistic MarkovLR (no graph conv)
    # ============================

    print("Initializing MarkovLR probabilistic baseline...")

    # If you have segment timestamps in some array t_seg (len = num_nodes), pass it.
    # Otherwise it will default to index order.
    order = build_order_from_segment_time(graph_data, t_seg=None)

    markov_model = MarkovLogReg(input_dim=graph_data.x.size(1), l2=1e-4).to(graph_data.x.device)

    print("Training MarkovLR...")
    markov_model = train_markov_lr(
        markov_model,
        graph_data,
        order=order,
        epochs=300,
        lr=0.01,
        weight_decay=1e-4
    )

    print("Evaluating MarkovLR...")
    auc_mk, ap_mk = evaluate_markov_lr_ap_auc(markov_model, graph_data, order=order)

    append_metrics(args.metrics_csv, args.trial_id, args.seed, "MarkovLR", auc_mk, ap_mk)


if __name__ == "__main__":
    main()
