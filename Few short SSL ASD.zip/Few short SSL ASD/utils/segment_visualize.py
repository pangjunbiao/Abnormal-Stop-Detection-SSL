import matplotlib.pyplot as plt

def visualize_segment_summary(segment_summary, use_sas=True):
    # Clip durations for consistent comparison
    cleaned_duration = segment_summary['total_stop_duration_sec'].clip(lower=0, upper=2000)
    segment_lengths = segment_summary['segment_length_km']

    # 1. Segment Length Histogram
    plt.figure()
    plt.hist(segment_lengths, bins=30, color='skyblue', edgecolor='black')

    if use_sas:
        plt.title("Segment Length Distribution (by SAS)")
        plt.xlim(0, 30)  # Wide spread since SAS segments vary greatly
    else:
        plt.title("Segment Length Distribution (Fixed-Length)")
        max_val = segment_lengths.max()
        # Dynamically stretch x-axis slightly beyond max value for visibility
        plt.xlim(0, max_val * 1.2 if max_val < 5 else 30)

    plt.xlabel("Segment Length (km)")
    plt.ylabel("Count")
    plt.grid(True)
    plt.tight_layout()
    plt.show()

    # 2. Stop Duration Histogram
    plt.figure()
    plt.hist(cleaned_duration, bins=40, color='salmon', edgecolor='black')
    plt.title("Total Stop Duration per Segment (0–2000s, Clipped)")
    plt.xlabel("Total Stop Duration (sec)")
    plt.ylabel("Count")
    plt.xlim(0, 2000)
    plt.grid(True)
    plt.tight_layout()
    plt.show()
