import numpy as np
import torch
from sklearn.semi_supervised import LabelPropagation
from sklearn.metrics.pairwise import cosine_similarity

def run_label_propagation(
    graph_data,
    max_iter=1000,
    high_thresh=0.995,
    low_thresh=0.005,
    max_pseudo_ratio=0.3,
    downsample_normal=350,
    cap_abnormal=50
):
    """
    Project-Aligned Label Propagation:
    Conservative propagation from limited labels over the LTIGA-smoothed graph.
    Ensures balanced pseudo-labeling by applying confidence thresholds and class caps.
    """
    # Extract features and labels
    X = graph_data.x.cpu().numpy()
    y = graph_data.y.cpu().numpy()

    # Step 1: Optional downsampling of label 1 (normal) to avoid skewed propagation
    normal_indices = np.where(y == 1)[0]
    if len(normal_indices) > downsample_normal:
        selected = np.random.choice(normal_indices, downsample_normal, replace=False)
        y[normal_indices] = -1
        y[selected] = 1
        print(f"✅ Downsampled label 1 from {len(normal_indices)} to {downsample_normal}")

    # Step 2: Remove NaNs from X before fitting
    mask = ~np.isnan(X).any(axis=1)
    X_clean = X[mask]
    y_clean = y[mask]
    clean_indices = np.where(mask)[0]
    print(f"⚠️ Skipped {len(X) - len(X_clean)} nodes due to NaNs in features.")

    if np.all(y_clean == -1):
        print("⚠️ No labeled nodes available after NaN filtering. Skipping propagation...")
        return torch.tensor(y, dtype=torch.long)

    # Step 3: Fit label propagation model
    label_prop = LabelPropagation(kernel='rbf', max_iter=max_iter)
    label_prop.fit(X_clean, y_clean)
    probs = label_prop.label_distributions_
    propagated = label_prop.transduction_

    # Step 4: Thresholding for high-confidence pseudo-labels
    refined = y.copy()
    for i, idx in enumerate(clean_indices):
        if y[idx] == -1:
            prob = probs[i][1]
            if prob >= high_thresh:
                refined[idx] = 1
            elif prob <= low_thresh:
                refined[idx] = 0

    # Step 5: Limit total pseudo-labels
    new_indices = np.where((refined != -1) & (y == -1))[0]
    max_pseudo = int(len(y) * max_pseudo_ratio)
    if len(new_indices) > max_pseudo:
        drop = np.random.choice(new_indices, len(new_indices) - max_pseudo, replace=False)
        refined[drop] = -1
        print(f"⚠️ Limited total pseudo-labels to {max_pseudo}")

    # Step 6: Cap number of abnormal pseudo-labels (label 0)
    abnormal_new = np.where((refined == 0) & (y == -1))[0]
    if len(abnormal_new) > cap_abnormal:
        drop = np.random.choice(abnormal_new, len(abnormal_new) - cap_abnormal, replace=False)
        refined[drop] = -1
        print(f"⚠️ Capped abnormal pseudo-labels to {cap_abnormal}")

    # Final summary
    print("📊 Original label distribution:", dict(zip(*np.unique(y, return_counts=True))))
    print("📈 Refined label distribution:", dict(zip(*np.unique(refined, return_counts=True))))

    return torch.tensor(refined, dtype=torch.long)