# save_abnormal_stops_after_self_training.py

import os
import pandas as pd
import torch

def save_abnormal_stops_after_self_training(model, graph_data, segmented_data_with_gps, output_path="./data/results/abnormal_segments_final.csv", threshold=0.26):
    """
    Save all GPS points (latitude, longitude) belonging to segments predicted as abnormal (label 0) based on model probabilities.

    Args:
        model: Trained GCN model.
        graph_data: Graph data object (PyG Data) for prediction.
        segmented_data_with_gps: DataFrame with 'segment_id', 'latitude', and 'longitude' columns.
        output_path: Path to save the CSV.
        threshold: Threshold for probability to classify as abnormal (default 0.26).
    """

    model.eval()
    with torch.no_grad():
        probs = model.get_probabilities(graph_data).cpu()

    # 1. Predict labels from probs
    predicted_labels = (probs >= threshold).long().cpu()  # 0 = abnormal, 1 = normal

    # 2. Find abnormal node indices
    abnormal_node_indices = (predicted_labels == 0).nonzero(as_tuple=False).squeeze().tolist()

    if isinstance(abnormal_node_indices, int):
        abnormal_node_indices = [abnormal_node_indices]

    print(f"✅ Total abnormal nodes (label 0): {len(abnormal_node_indices)}")

    # 3. Get segment IDs for abnormal nodes
    abnormal_segment_ids = graph_data.segment_id[abnormal_node_indices].cpu().numpy()
    abnormal_segment_ids = set(abnormal_segment_ids)

    print(f"✅ Total unique abnormal segments found: {len(abnormal_segment_ids)}")

    # 4. Select all GPS points belonging to abnormal segments
    abnormal_rows = segmented_data_with_gps[segmented_data_with_gps['segment_id'].isin(abnormal_segment_ids)]

    if abnormal_rows.empty:
        print("⚠️ Warning: No abnormal GPS points found.")
    else:
        abnormal_rows = abnormal_rows[['segment_id', 'latitude', 'longitude']]
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        abnormal_rows.to_csv(output_path, index=False)
        print(f"✅ Saved {len(abnormal_rows)} abnormal GPS points to {output_path}")
        print(f"✅ Covered {len(abnormal_segment_ids)} abnormal segments")
