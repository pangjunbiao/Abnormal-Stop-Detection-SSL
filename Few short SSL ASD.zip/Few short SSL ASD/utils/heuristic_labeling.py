import pandas as pd
import numpy as np

def apply_heuristic_rules(df,
                          stop_duration_bounds=(1.0, 10.0),  # minutes
                          speed_threshold=0.5,              # km/h
                          stay_time_bounds=(2, 30),         # minutes
                          path_deviation_threshold=150,     # meters
                          location_consistency_threshold=0.5):
    """
    Apply a series of heuristic rules to assign pseudo-labels to GPS data.
    Rules are used to identify high-confidence normal stops (label 1).
    Assumes abnormal stops (label 0) are pre-assigned elsewhere.
    """

    df = df.copy()
    df['pseudo_label'] = df.get('pseudo_label', -1)  # Initialize if not already set

    # Heuristic 1: Stop Duration and Speed Stability
    mask1 = (
        (df['stop_duration'] >= stop_duration_bounds[0]) &
        (df['stop_duration'] <= stop_duration_bounds[1]) &
        (df['speed_diff'].abs() < speed_threshold)
    )

    # Heuristic 2: Stop Duration and Stay Time
    mask2 = (
        (df['stop_duration'] >= stop_duration_bounds[0]) &
        (df['stop_duration'] <= stop_duration_bounds[1]) &
        (df['stay_time'] >= stay_time_bounds[0]) &
        (df['stay_time'] <= stay_time_bounds[1])
    )

    # Heuristic 3: Path Deviation and Location Consistency
    location_counts = df.groupby(['latitude', 'longitude']).size()
    df['location_consistency'] = df[['latitude', 'longitude']].apply(tuple, axis=1).map(location_counts) / len(df)

    mask3 = (
        (df['path_deviation'] < path_deviation_threshold) &
        (df['location_consistency'] > location_consistency_threshold)
    )

    # Combine all heuristics (logical OR)
    high_confidence_normal = mask1 | mask2 | mask3
    df.loc[high_confidence_normal, 'pseudo_label'] = 1

    # Preserve existing abnormal stop labels (0), and reset other rows to -1
    df['pseudo_label'] = np.where(
        (df['pseudo_label'] != 0) & (df['pseudo_label'] != 1),
        -1,
        df['pseudo_label']
    )

    return df
