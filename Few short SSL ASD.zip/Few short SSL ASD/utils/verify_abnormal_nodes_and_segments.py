# verify_predicted_abnormal_nodes_and_segments.py

import torch
from collections import Counter

def verify_abnormal_nodes_and_segments(graph_data, probs=None, threshold=0.26):
    """
    Verifies and prints the number of abnormal nodes and abnormal segments based on final model predictions.

    Args:
        graph_data: Graph data object (PyG Data) with labels (graph_data.y).
        probs (torch.Tensor, optional): If provided, use model predicted probabilities instead of graph_data.y.
        threshold (float, optional): Threshold to classify nodes as abnormal (default 0.26).
    """

    if probs is not None:
        # ✅ Predict labels based on model probabilities
        predicted_labels = (probs >= threshold).long().cpu()
        print("⚡ Using model probabilities to verify predicted labels.")
    else:
        # ✅ Use existing labels from graph_data.y
        predicted_labels = graph_data.y.cpu()
        print("⚡ Using existing graph_data.y (already updated labels).")

    # 1. Find abnormal nodes (label 0)
    abnormal_node_indices = (predicted_labels == 0).nonzero(as_tuple=False).squeeze().tolist()

    if isinstance(abnormal_node_indices, int):
        abnormal_node_indices = [abnormal_node_indices]

    total_abnormal_nodes = len(abnormal_node_indices)

    # 2. Get segment IDs of these nodes
    abnormal_segment_ids = graph_data.segment_id[abnormal_node_indices].cpu().numpy()
    unique_abnormal_segments = set(abnormal_segment_ids)

    total_abnormal_segments = len(unique_abnormal_segments)

    print("\n✅ Verification Results:")
    print(f"  ➤ Total abnormal nodes (label 0): {total_abnormal_nodes}")
    print(f"  ➤ Total unique abnormal segments: {total_abnormal_segments}")

    # Optional detailed output
    print("\n📊 Detailed Predicted Label Distribution (Counter):")
    print(Counter(predicted_labels.numpy()))

    return total_abnormal_nodes, total_abnormal_segments
