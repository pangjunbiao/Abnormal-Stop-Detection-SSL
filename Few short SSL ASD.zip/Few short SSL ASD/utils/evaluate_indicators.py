from sklearn.metrics import roc_auc_score, average_precision_score
import numpy as np

def evaluate_indicators(before_data, after_data=None, true_labels=None, use_weighted_confidence=True):
    """
    Evaluates the indicators before and after LTIGA using AUC and AP metrics.

    Args:
        before_data (DataFrame): Data before LTIGA.
        after_data (DataFrame, optional): Data after LTIGA.
        true_labels (array-like, optional): Ground-truth labels.
        use_weighted_confidence (bool): If True, use weighted indicators; otherwise use unweighted.
    """
    suffix = "Weighted" if use_weighted_confidence else ""
    metrics = [f"{suffix}TIS", f"{suffix}MSD", f"{suffix}TTA@k"]

    if true_labels is not None:
        valid_mask = (true_labels != -1)

        for metric in metrics:
            if metric in before_data.columns:
                y_score_before = before_data.loc[valid_mask, metric]

                # Drop NaNs
                mask_nonan = ~y_score_before.isna()
                y_score_before = y_score_before[mask_nonan]
                filtered_labels = true_labels[valid_mask][mask_nonan]

                if len(filtered_labels) > 0:
                    auc_before = roc_auc_score(filtered_labels, y_score_before)
                    ap_before = average_precision_score(filtered_labels, y_score_before)
                    print(f"Before LTIGA ({metric}) - AUC: {auc_before:.4f}, AP: {ap_before:.4f}")
                else:
                    print(f"[Warning] No valid entries for {metric} before LTIGA.")

            if after_data is not None and metric in after_data.columns:
                y_score_after = after_data.loc[valid_mask, metric]
                mask_nonan = ~y_score_after.isna()
                y_score_after = y_score_after[mask_nonan]
                filtered_labels = true_labels[valid_mask][mask_nonan]

                if len(filtered_labels) > 0:
                    auc_after = roc_auc_score(filtered_labels, y_score_after)
                    ap_after = average_precision_score(filtered_labels, y_score_after)
                    print(f"After LTIGA ({metric}) - AUC: {auc_after:.4f}, AP: {ap_after:.4f}")
                else:
                    print(f"[Warning] No valid entries for {metric} after LTIGA.")

    else:
        for metric in metrics:
            if metric in before_data.columns:
                print(f"Before LTIGA ({metric}):")
                print(before_data[metric].describe())
            if after_data is not None and metric in after_data.columns:
                print(f"After LTIGA ({metric}):")
                print(after_data[metric].describe())