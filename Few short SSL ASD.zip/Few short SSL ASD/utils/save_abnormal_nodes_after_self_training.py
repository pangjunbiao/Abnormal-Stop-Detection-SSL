# save_abnormal_nodes_after_self_training.py

import os
import pandas as pd
import torch

def save_abnormal_nodes_after_self_training(model, graph_data, output_path="./data/results/abnormal_nodes_after_st.csv", threshold=0.26):
    """
    Save node-level abnormal predictions (node index, segment_id, optional probability) after self-training.

    Args:
        model: Trained GCN model.
        graph_data: Graph data object (PyG Data) containing node info.
        output_path: Path to save the output CSV.
        threshold: Threshold to classify nodes as abnormal (default 0.26).
    """

    model.eval()
    with torch.no_grad():
        probs = model.get_probabilities(graph_data).cpu()

    # 1. Predict final labels
    predicted_labels = (probs >= threshold).long().cpu()

    # 2. Find abnormal nodes (label 0)
    abnormal_node_indices = (predicted_labels == 0).nonzero(as_tuple=False).squeeze().tolist()

    if isinstance(abnormal_node_indices, int):
        abnormal_node_indices = [abnormal_node_indices]

    print(f"✅ Total abnormal nodes to save: {len(abnormal_node_indices)}")

    # 3. Prepare DataFrame
    node_indices = abnormal_node_indices
    segment_ids = graph_data.segment_id[abnormal_node_indices].cpu().numpy()
    probabilities = probs[abnormal_node_indices].squeeze().numpy()

    abnormal_nodes_df = pd.DataFrame({
        "node_index": node_indices,
        "segment_id": segment_ids,
        "probability": probabilities
    })

    # 4. Save
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    abnormal_nodes_df.to_csv(output_path, index=False)

    print(f"✅ Abnormal nodes saved to {output_path}")
