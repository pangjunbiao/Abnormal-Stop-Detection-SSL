import pandas as pd
import numpy as np
import os

def calculate_indicators_by_segment(
    df,
    min_points_per_segment=2,
    min_total_distance=0.01,
    debug_output_path="./data/processed_data/indicator_debug_log.csv"
):
    """
    Compute TIS, MSD, and TTA@k indicators per segment.
    Applies confidence weighting based on segment size and speed.
    Saves detailed indicator summary to CSV for debugging.
    """
    indicators = []
    grouped = df.groupby('segment_id')

    max_points = grouped.size().max() if not grouped.size().empty else 1  # For confidence normalization

    # print("Debugging Indicator Calculation Input:")
    # print(f"Total segments: {len(grouped)}")

    for segment_id, group in grouped:
        # Filter sparse or invalid segments
        d_total = group['distance_from_start'].max() - group['distance_from_start'].min()
        if len(group) < min_points_per_segment or d_total < min_total_distance:
            continue

        s_total = group['stop_duration'].sum()
        v_avg = group['speed'].mean()
        v_max = group['speed'].max()

        if v_avg <= 0 or v_max <= 0 or s_total <= 0:
            continue

        # # Debugging values for the segment
        # print(f"Processing Segment {segment_id}:")
        # print(f"  Stop Duration: {s_total}")
        # print(f"  Average Speed: {v_avg}")
        # print(f"  Max Speed: {v_max}")
        # print(f"  Total Distance: {d_total}")

        # Base indicators
        tis = s_total / (d_total * (s_total / v_avg))
        msd = abs(v_max - v_avg) + 0.1 * v_avg
        k = min(3, len(group))
        top_k_stops = group['stop_duration'].nlargest(k).sum()
        ttak = (top_k_stops / k) * (s_total / group['stop_duration'].sum())

        # Confidence score
        confidence = (len(group) / max_points) * (v_avg / v_max)

        # Add to indicator list
        indicators.append({
            'segment_id': segment_id,
            'TIS': tis,
            'MSD': msd,
            'TTA@k': ttak,
            'WeightedTIS': tis * confidence,
            'WeightedMSD': msd * confidence,
            'WeightedTTA@k': ttak * confidence,
            'Confidence': confidence,
            'num_points': len(group),
            'total_stop_duration': s_total,
            'avg_speed': v_avg,
            'total_distance': d_total
        })

    # Create DataFrame and save for inspection
    indicator_df = pd.DataFrame(indicators)
    os.makedirs(os.path.dirname(debug_output_path), exist_ok=True)
    indicator_df.to_csv(debug_output_path, index=False)

    print(f"Indicator DataFrame Preview: {indicator_df.head()}")
    return indicator_df

