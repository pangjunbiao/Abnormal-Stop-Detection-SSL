import os
import pandas as pd
import numpy as np
from geopy.distance import geodesic

from models.graph.feature_embedding import calculate_features
from utils.heuristic_labeling import apply_heuristic_rules
from models.graph.SAGE_segmentation import segment_road_by_distance_and_time

def assign_column_names(df):
    column_names = [
        "longitude", "latitude", "stay_time", "distance_from_start",
        "speed", "distance_from_previous", "traffic_light_label",
        "date", "time", "license_plate", "arrival_clustering_time"
    ]
    if df.shape[1] == len(column_names):
        df.columns = column_names
        print("Assigned column names.")
    else:
        raise ValueError(f"Expected {len(column_names)} columns, found {df.shape[1]}")
    return df

def load_raw_data(directory):
    print(f"Loading raw data from {directory}...")
    dataframes, skipped_files = [], []

    for file in os.listdir(directory):
        if file.endswith(".txt"):
            try:
                df = pd.read_csv(os.path.join(directory, file), header=None, delimiter="\t", usecols=range(11))
                df = assign_column_names(df)
                dataframes.append(df)
                print(f"Loaded {file} with shape {df.shape}")
            except Exception as e:
                skipped_files.append((file, str(e)))
                print(f"Error loading {file}: {e}")

    if not dataframes:
        raise ValueError("No valid files found in the directory.")

    combined_data = pd.concat(dataframes, ignore_index=True)
    print(f"Combined shape: {combined_data.shape}")

    if skipped_files:
        pd.DataFrame(skipped_files, columns=["file", "error"]).to_csv(
            "./data/processed_data/skipped_files.csv", mode='a', index=False,
            header=not os.path.exists("./data/processed_data/skipped_files.csv")
        )
        print("Logged skipped files.")

    return combined_data

def compute_features(data):
    data = data.copy()

    data["speed"] = pd.to_numeric(data["speed"], errors="coerce")
    data["stay_time"] = data["stay_time"].clip(lower=0)

    print("🔍 stay_time stats after clipping:", data["stay_time"].describe())

    data = data[data["speed"] >= 0]  # Remove negative speeds

    data["acceleration"] = data["speed"].diff() / data["stay_time"].replace(0, np.nan)
    data["time_of_day"] = pd.to_datetime(data["time"], unit="s", errors="coerce").dt.hour
    data["distance_to_next"] = data["distance_from_previous"].shift(-1)
    data["travel_time_to_next"] = data["stay_time"].shift(-1)
    data["speed_diff"] = data["speed"].diff().fillna(0)
    data["stop_duration"] = data["stay_time"]
    print("🔍 stop_duration stats:", data["stop_duration"].describe())
    data["path_deviation"] = np.sqrt(
        (data["longitude"] - data["longitude"].shift()) ** 2 +
        (data["latitude"] - data["latitude"].shift()) ** 2
    ) * 111320  # Convert degrees to meters

    return data.dropna()

def match_true_stops_to_raw_data(raw_data, true_GPS, distance_threshold=0.101):
    raw_data["pseudo_label"] = -1
    for lng, lat in np.array(true_GPS):
        distances = raw_data.apply(
            lambda row: geodesic((row['latitude'], row['longitude']), (lat, lng)).km, axis=1
        )
        raw_data.loc[distances <= distance_threshold, 'pseudo_label'] = 0
    return raw_data

def preprocess_data(raw_data_dir, processed_data_path, skipped_data_path, true_GPS):
    # Step 1: Load raw data
    raw_data = load_raw_data(raw_data_dir)

    # Step 2: Feature Engineering (Do not apply SAS or LTIGA here)
    print("Feature Engineering on raw data...")
    data = compute_features(raw_data)

    # Step 3: Label Matching (Assign pseudo labels based on true stops)
    print("Matching true stops...")
    data = match_true_stops_to_raw_data(data, true_GPS)

    # Step 4: Heuristic Labeling (Apply rules to generate pseudo labels)
    print("Applying heuristic rules to generate pseudo labels...")
    data = apply_heuristic_rules(data)

    # Step 5: Save Preprocessed Data (without SAS and LTIGA)
    print("Saving preprocessed data...")
    data.to_csv(processed_data_path, index=False)
    print(f"Processed data saved to {processed_data_path}")

    skipped_rows = raw_data[~raw_data.index.isin(data.index)]
    if not skipped_rows.empty:
        skipped_rows.to_csv(skipped_data_path, index=False)
        print(f"Saved skipped rows to {skipped_data_path}")

    return data
