import matplotlib.pyplot as plt
from sklearn.metrics import roc_auc_score, average_precision_score

def plot_auc_ap_scores(data, true_labels, metrics, title_suffix="Before LTIGA", use_weighted=False, save_path=None):
    """
    Plots AUC and AP scores for selected indicators.

    Args:
        data (DataFrame): Data containing indicator scores.
        true_labels (array-like): Ground-truth binary labels (0/1).
        metrics (list): List of base indicator names (e.g., ["TIS", "MSD", "TTA@k"]).
        title_suffix (str): Suffix to describe evaluation context (e.g., "Before LTIGA").
        use_weighted (bool): Whether to use weighted indicators.
        save_path (str, optional): Path to save the plot as a PNG.
    """
    suffix = "Weighted" if use_weighted else ""
    valid_mask = (true_labels != -1)
    filtered_labels_all = true_labels[valid_mask]

    auc_scores = []
    ap_scores = []
    final_metrics = []

    for metric in metrics:
        column = f"{suffix}{metric}"
        if column not in data.columns:
            print(f"[Warning] {column} not found in data. Skipping...")
            continue

        y_scores = data.loc[valid_mask, column]
        non_nan_mask = ~y_scores.isna()
        y_scores_clean = y_scores[non_nan_mask]
        filtered_labels = filtered_labels_all[non_nan_mask]

        if len(filtered_labels) == 0:
            print(f"[Warning] No valid data for {column}. Skipping...")
            continue

        auc = roc_auc_score(filtered_labels, y_scores_clean)
        ap = average_precision_score(filtered_labels, y_scores_clean)

        auc_scores.append(auc)
        ap_scores.append(ap)
        final_metrics.append(metric)

    # Set descriptive title
    if title_suffix.lower() == "before ltiga":
        plot_title = "Indicator Performance on Raw Data"
    elif title_suffix.lower() == "after ltiga":
        plot_title = "Indicator Performance After LTIGA"
    else:
        plot_title = f"Indicator Performance ({title_suffix})"

    # Plotting
    x = range(len(final_metrics))
    plt.figure(figsize=(8, 5))
    plt.bar(x, auc_scores, width=0.4, label='AUC', align='center', color='darkorange')
    plt.bar([i + 0.4 for i in x], ap_scores, width=0.4, label='AP', align='center', color='steelblue')
    plt.xticks([i + 0.2 for i in x], final_metrics)
    plt.ylabel("Score")
    plt.title(plot_title)
    plt.ylim(0, 1)
    plt.legend()
    plt.tight_layout()

    if save_path:
        plt.savefig(save_path)
        print(f"[Saved] AUC/AP plot at {save_path}")
    else:
        plt.show()