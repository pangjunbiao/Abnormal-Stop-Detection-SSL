# visualizations/plot_segment_abnormality_scores.py

import os
import matplotlib.pyplot as plt
import numpy as np
import torch


def plot_segment_abnormality_scores(
        model,
        graph_data,
        segment_ids,
        output_path="./data/results/segment_abnormality_scores.png",
        top_n=160
):
    """
    Plots the mean abnormality probability for the first top_n segments.
    """

    model.eval()
    with torch.no_grad():
        probs = model.get_probabilities(graph_data).cpu()

    segment_ids = segment_ids.cpu()
    unique_segments = torch.unique(segment_ids)
    selected_segments = unique_segments[:top_n]

    mean_probs = []
    segment_indices = []

    for seg_id in selected_segments:
        mask = (segment_ids == seg_id)
        if mask.any():
            mean_probs.append(probs[mask].mean().item())
            segment_indices.append(seg_id.item())

    # Ensure output directory exists
    os.makedirs(os.path.dirname(output_path), exist_ok=True)

    # Plot
    plt.figure(figsize=(12, 5))
    plt.plot(segment_indices, mean_probs, marker='o', linestyle='-', color='darkred', linewidth=1.5)
    plt.title(f"Segment-wise Abnormality Scores (First {top_n} Segments)", fontsize=14)
    plt.xlabel("Segment ID (Natural Order)", fontsize=12)
    plt.ylabel("Mean Abnormality Probability", fontsize=12)
    plt.ylim(0.4, 1.0)  # Focused view on confidence zone
    plt.grid(True, linestyle='--', alpha=0.5)
    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()

    print(f"✅ Segment-wise abnormality scores plot saved to {output_path}")
