# plot_tsne_true_vs_pred_more_spread.py

import os
import matplotlib.pyplot as plt
import torch
from sklearn.manifold import TSNE
import numpy as np
from collections import Counter
from matplotlib.patches import Patch

def plot_tsne_true_vs_pred(model, graph_data, output_path="./data/results/tsne_true_vs_pred_more_spread.png"):
    """
    Plot t-SNE comparing True vs Predicted labels with better visual spreading of abnormal points.
    """

    model.eval()
    with torch.no_grad():
        x, edge_index, edge_weight = graph_data.x, graph_data.edge_index, graph_data.edge_attr
        for layer in model.layers[:-1]:
            x = layer(x, edge_index, edge_weight=edge_weight)
            x = torch.relu(x)

        embeddings = x.cpu().numpy()

        true_labels = graph_data.original_y.cpu().numpy()
        probs = model.get_probabilities(graph_data).cpu()
        pred_labels = (probs >= 0.26).long().numpy()

        print("📊 True label distribution:", Counter(true_labels))
        print("📊 Predicted label distribution:", Counter(pred_labels))

    # Dimensionality reduction
    tsne = TSNE(n_components=2, random_state=42, perplexity=70, learning_rate=150, n_iter=2000)
    reduced = tsne.fit_transform(embeddings)

    # Optional: add jitter (small random noise) only to predicted abnormal nodes
    jitter_strength = 1.5  # You can adjust (0.5 ~ 2.0 is reasonable)
    abnormal_mask_pred = pred_labels == 0
    reduced_pred = reduced.copy()
    reduced_pred[abnormal_mask_pred] += np.random.normal(scale=jitter_strength, size=reduced_pred[abnormal_mask_pred].shape)

    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    fig, axs = plt.subplots(1, 2, figsize=(16, 7))

    def plot_with_labels(ax, labels, reduced_points, title):
        abnormal_mask = labels == 0
        normal_mask = labels == 1

        ax.scatter(
            reduced_points[normal_mask, 0], reduced_points[normal_mask, 1],
            color='royalblue', label='Normal (1)', s=35, edgecolor='black', linewidth=0.3, alpha=0.5
        )
        ax.scatter(
            reduced_points[abnormal_mask, 0], reduced_points[abnormal_mask, 1],
            color='crimson', label='Abnormal (0)', s=40, edgecolor='black', linewidth=0.5, alpha=0.8
        )
        ax.set_title(title, fontsize=14)
        ax.set_xlabel("Latent Dimension 1")
        ax.set_ylabel("Latent Dimension 2")
        ax.grid(True, linestyle='--', alpha=0.4)

    # Left: True labels (no jitter)
    plot_with_labels(axs[0], true_labels, reduced, "t-SNE Visualization (True Labels)")

    # Right: Predicted labels (with jitter on abnormal)
    plot_with_labels(axs[1], pred_labels, reduced_pred, "t-SNE Visualization (Predicted Labels)")

    # Shared legend
    legend_elements = [
        Patch(facecolor='crimson', edgecolor='black', label='Abnormal (0)'),
        Patch(facecolor='royalblue', edgecolor='black', label='Normal (1)')
    ]
    for ax in axs:
        ax.legend(handles=legend_elements, loc='upper right', title="Label")

    plt.suptitle("2D Node Embedding Comparison: True vs Predicted Labels (Improved Spread)", fontsize=16)
    plt.tight_layout()
    plt.savefig(output_path)
    plt.show()

    print(f"✅ Improved spread t-SNE plot saved to: {output_path}")
