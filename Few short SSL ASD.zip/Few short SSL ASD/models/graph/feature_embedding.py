import numpy as np
import pandas as pd

def calculate_tis(data):
    """
    Calculate Temporal Influence Score (TIS) based on deviation from median stay_time.
    Highlights truly abnormal stop durations relative to the segment.
    """
    stats = data.groupby("segment_id")["stay_time"].agg(['median', 'std']).rename(columns={"median": "med", "std": "stddev"})
    data = data.merge(stats, left_on="segment_id", right_index=True, how="left")

    epsilon = 1e-6
    data["TIS"] = (data["stay_time"] - data["med"]) / (data["stddev"] + epsilon)
    data["TIS"] = data["TIS"].clip(lower=0, upper=3)

    return data.drop(columns=["med", "stddev"])

def calculate_msd(data):
    """
    Revised MSD: Robust deviation from median speed using Median Absolute Deviation (MAD).
    """
    def robust_deviation(group):
        median_speed = group.median()
        mad = np.median(np.abs(group - median_speed)) + 1e-6
        return np.abs(group - median_speed) / mad

    data["MSD"] = data.groupby("segment_id")["speed"].transform(robust_deviation)
    data["MSD"] = data["MSD"].clip(upper=3)  # Optional clipping
    return data


def calculate_tta(data, k=2, dynamic_k=False):
    """
    Top-k Temporal Aggregation (TTA@k)
    """
    def top_k_avg(group, k):
        group['normalized_stay_time'] = (group['stay_time'] - group['stay_time'].min()) / \
                                        (group['stay_time'].max() - group['stay_time'].min() + 1e-9)
        k = min(len(group), k)
        return group.nlargest(k, 'normalized_stay_time')['normalized_stay_time'].mean()

    if dynamic_k:
        segment_sizes = data.groupby("segment_id")["stay_time"].count()
        segment_k = (segment_sizes * 0.1).clip(lower=1, upper=k).astype(int)
    else:
        segment_k = pd.Series(k, index=data['segment_id'].unique())

    tta_values = data.groupby("segment_id").apply(lambda x: top_k_avg(x, segment_k[x.name])).reset_index(name="TTA@k")

    data = data.drop(columns=["TTA@k"], errors="ignore")
    data = data.merge(tta_values, on="segment_id", how="left")

    return data

def calculate_confidence_scores(data):
    """
    Compute a confidence score per segment based on number of points and speed.
    """
    segment_info = data.groupby('segment_id').agg(
        num_points=('segment_id', 'count'),
        avg_speed=('speed', 'mean'),
        max_speed=('speed', 'max')
    ).reset_index()

    max_points = segment_info['num_points'].max()
    segment_info['confidence'] = (segment_info['num_points'] / max_points) * \
                                 (segment_info['avg_speed'] / (segment_info['max_speed'] + 1e-9))

    return segment_info[['segment_id', 'confidence']]

def apply_confidence_weights(data):
    """
    Apply confidence weights to indicators TIS, MSD, TTA@k
    """
    conf_scores = calculate_confidence_scores(data)
    data = data.merge(conf_scores, on='segment_id', how='left')

    for col in ['TIS', 'MSD', 'TTA@k']:
        if col in data.columns:
            weighted_col = f"Weighted{col}"
            data[weighted_col] = data[col] * data['confidence']

    return data

def calculate_features(data, use_weighted_confidence=False):
    """
    Calculate indicators with optional confidence weighting.
    """
    data = calculate_tis(data)
    data = calculate_msd(data)
    data = calculate_tta(data, k=2)
    if use_weighted_confidence:
        data = apply_confidence_weights(data)
    return data

def embed_node_features(data, output_file_path="./data/processed_data/node_features.csv"):
    """
    Embed final node features for GCN input.
    Supports both weighted and unweighted indicators.
    """
    columns = [
        'latitude', 'longitude', 'stay_time', 'speed', 'acceleration',
        'time_of_day'
    ]

    # Add weighted indicators if they exist, else fallback to unweighted
    if 'WeightedTIS' in data.columns:
        columns += ['WeightedTIS', 'WeightedMSD', 'WeightedTTA@k']
    elif 'TIS' in data.columns:
        columns += ['TIS', 'MSD', 'TTA@k']

    node_features = data[columns]
    node_features.to_csv(output_file_path, index=False)
    return node_features