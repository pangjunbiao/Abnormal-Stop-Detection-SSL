import pandas as pd
import numpy as np
import logging

logging.basicConfig(level=logging.INFO)

def segment_road_by_distance_and_time(
    data,
    distance_threshold=None,
    time_threshold=None,
    adaptive=True,
    alpha=1.0,
    beta=1.0,
    min_points_threshold=5
):
    '''
    SAGE: Sparsity-Aware Graph-Enhanced Segmentation (SAS mode)
    Applies adaptive segmentation based on distance and stop-time statistics.
    '''
    if 'distance_from_start' not in data.columns or 'stay_time' not in data.columns:
        raise ValueError("Missing 'distance_from_start' or 'stay_time' columns.")

    data = data.sort_values(by='distance_from_start').reset_index(drop=True)
    data['distance_delta'] = data['distance_from_start'].diff().fillna(0)
    data['time_delta'] = data['stay_time'].fillna(0)

    if adaptive:
        mu_d, sigma_d = data['distance_delta'].mean(), data['distance_delta'].std()
        mu_t, sigma_t = data['time_delta'].mean(), data['time_delta'].std()
        distance_threshold = mu_d + alpha * sigma_d
        time_threshold = mu_t + beta * sigma_t
        logging.info(f"[Adaptive] distance_threshold = {distance_threshold:.4f} km")
        logging.info(f"[Adaptive] time_threshold = {time_threshold:.2f} sec")
    else:
        if distance_threshold is None or time_threshold is None:
            raise ValueError("Must provide distance and time thresholds when adaptive=False")

    segment_id = 0
    segment_ids = [0]
    last_index = 0

    for i in range(1, len(data)):
        d = data.loc[i, 'distance_from_start'] - data.loc[last_index, 'distance_from_start']
        t = data.loc[i, 'stay_time']
        if d > distance_threshold or t > time_threshold:
            segment_id += 1
            last_index = i
        segment_ids.append(segment_id)

    data['segment_id'] = segment_ids
    return data.drop(columns=['distance_delta', 'time_delta'])

def segment_fixed_length(data, fixed_length_km=2.0):
    """
    Fixed-Length Segmentation (baseline)
    Splits GPS trajectories into segments of approximately fixed spatial length.
    """
    if 'distance_from_start' not in data.columns:
        raise ValueError("Missing 'distance_from_start' column.")

    # Sort data to ensure consistency
    data = data.sort_values(by='distance_from_start').reset_index(drop=True)

    segment_id = 0
    last_split_distance = data.loc[0, 'distance_from_start']
    segment_ids = [segment_id]

    for i in range(1, len(data)):
        current_distance = data.loc[i, 'distance_from_start']
        if current_distance - last_split_distance >= fixed_length_km:
            segment_id += 1
            last_split_distance = current_distance
        segment_ids.append(segment_id)

    data['segment_id'] = segment_ids
    return data


def summarize_segments(df):
    '''
    Outputs basic stats of segment structure (for debugging/inspection).
    '''
    if 'segment_id' not in df.columns:
        logging.warning("No 'segment_id' column found in DataFrame.")
        return None

    summary = df.groupby('segment_id').agg(
        num_points=('segment_id', 'count'),
        avg_speed=('speed', 'mean'),
        total_distance=('distance_from_previous', 'sum'),
        total_stop_duration=('stay_time', 'sum')
    ).reset_index()

    summary.to_csv("./data/processed_data/segment_summary.csv", index=False)
    logging.info("[Saved] Segment summary to './data/processed_data/segment_summary.csv']")
    return summary
