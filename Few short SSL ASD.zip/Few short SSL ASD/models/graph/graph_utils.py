import networkx as nx
import torch
import pandas as pd
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity
from torch_geometric.data import Data
from sklearn.metrics.pairwise import cosine_similarity


def apply_ltiga_adjustment(df, k=3, use_gaussian=True, sigma=0.3, apply_inverse_norm=True):
    """
    Improved LTIGA: Applies localized smoothing on unweighted indicators (TIS, MSD, TTA@k)
    using cosine similarity and optional Gaussian kernel. Optionally applies inverse normalization (Eq. 16).
    """
    df = df.copy()
    segments = []

    for segment_id, group in df.groupby("segment_id"):
        group = group.copy()
        if len(group) < 2:
            segments.append(group)
            continue

        # Extract raw indicators
        indicators = group[["TIS", "MSD", "TTA@k"]].fillna(0).values
        mean = indicators.mean(axis=0)
        std = indicators.std(axis=0) + 1e-6
        normed = (indicators - mean) / std

        # Smoothing with similarity weighting
        similarity = cosine_similarity(normed)
        np.fill_diagonal(similarity, 0)
        if use_gaussian:
            similarity = np.exp(-(1 - similarity) ** 2 / (2 * sigma ** 2))

        smoothed = normed.copy()
        for i in range(len(group)):
            top_k = np.argsort(similarity[i])[-k:]
            weights = similarity[i, top_k]
            if weights.sum() > 0:
                smoothed[i] = np.average(normed[top_k], axis=0, weights=weights)

        # Eq. (16): Inverse normalization — only if enabled
        if apply_inverse_norm:
            smoothed = smoothed * std + mean

        # Replace original indicators
        group[["TIS", "MSD", "TTA@k"]] = smoothed
        segments.append(group)

    return pd.concat(segments, ignore_index=True)

def build_adaptive_graph(segmented_data):
    """
    Builds a PyG graph from segmented data, using intra- and inter-segment connections.
    """
    G = nx.Graph()

    # Create nodes
    for idx, row in segmented_data.iterrows():
        features = torch.tensor(row[['WeightedTIS', 'WeightedMSD', 'WeightedTTA@k']].values, dtype=torch.float)
        G.add_node(
            idx,
            features=features,
            label=row.get('pseudo_label', -1),
            segment_id=row['segment_id'],
            latitude=row['latitude'],
            longitude=row['longitude'],
            timestamp=row.get('timestamp', None)
        )

    # Intra-segment edges
    for segment_id, group in segmented_data.groupby('segment_id'):
        sorted_group = group.sort_values(by='timestamp') if 'timestamp' in group.columns else group
        indices = sorted_group.index.tolist()
        for i in range(len(indices) - 1):
            G.add_edge(indices[i], indices[i + 1], weight=1.0)

    # Inter-segment similarity edges
    nodes = list(G.nodes(data=True))
    for i in range(len(nodes)):
        for j in range(i + 1, len(nodes)):
            u, v = nodes[i][0], nodes[j][0]
            node_u, node_v = nodes[i][1], nodes[j][1]

            if node_u['segment_id'] != node_v['segment_id']:
                try:
                    t1, t2 = pd.to_datetime(node_u['timestamp']), pd.to_datetime(node_v['timestamp'])
                    if abs((t1 - t2).total_seconds()) < 300:
                        sim = cosine_similarity(
                            node_u['features'].numpy().reshape(1, -1),
                            node_v['features'].numpy().reshape(1, -1)
                        )[0][0]
                        G.add_edge(u, v, weight=float(sim))
                except:
                    continue

    # Build PyG Data object
    x = torch.stack([G.nodes[n]['features'] for n in G.nodes])
    edge_index = torch.tensor(list(G.edges), dtype=torch.long).t().contiguous()
    edge_attr = torch.tensor([G[u][v]['weight'] for u, v in G.edges], dtype=torch.float)
    y = torch.tensor([G.nodes[n]['label'] for n in G.nodes], dtype=torch.long)
    segment_id = torch.tensor([G.nodes[n]['segment_id'] for n in G.nodes], dtype=torch.long)

    data = Data(x=x, edge_index=edge_index, edge_attr=edge_attr, y=y)
    data.segment_id = segment_id
    return data
