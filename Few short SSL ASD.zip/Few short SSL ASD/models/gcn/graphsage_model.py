# ./models/gcn/graphsage_model.py

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import SAGEConv


class GraphSAGEMean(nn.Module):
    """
    GraphSAGE (mean aggregator) baseline.

    Notes:
    - Uses SAGEConv with default mean aggregation.
    - Ignores edge weights (SAGEConv does not consume edge_attr/edge_weight).
    - get_probabilities returns P(class=1)=P(normal), consistent with your evaluator.
    """

    def __init__(self, input_dim: int, hidden_dim: int = 64, output_dim: int = 2,
                 num_layers: int = 2, dropout: float = 0.5):
        super().__init__()
        assert num_layers >= 2, "GraphSAGEMean: num_layers must be >= 2"

        self.dropout = float(dropout)
        self.convs = nn.ModuleList()

        # input -> hidden
        self.convs.append(SAGEConv(input_dim, hidden_dim, aggr="mean"))

        # hidden -> hidden
        for _ in range(num_layers - 2):
            self.convs.append(SAGEConv(hidden_dim, hidden_dim, aggr="mean"))

        # hidden -> output
        self.convs.append(SAGEConv(hidden_dim, output_dim, aggr="mean"))

    def forward(self, data):
        x = data.x
        edge_index = data.edge_index

        for i, conv in enumerate(self.convs):
            x = conv(x, edge_index)
            if i < len(self.convs) - 1:
                x = F.relu(x)
                x = F.dropout(x, p=self.dropout, training=self.training)

        return F.log_softmax(x, dim=1)

    def get_probabilities(self, data):
        # P(class=1)=normal
        return torch.exp(self.forward(data))[:, 1]

    def predict(self, data):
        self.eval()
        with torch.no_grad():
            logits = self.forward(data)
            return torch.argmax(logits, dim=1)


def graphsage_loss(y_pred_log, y_true):
    """
    Class-weighted NLL loss on labeled nodes only (y != -1).
    Mirrors your GCN imbalance handling (without extra regularizers).
    """
    mask = (y_true != -1)
    y_true = y_true[mask]
    y_pred_log = y_pred_log[mask]

    # fallback if only one class present
    num_0 = (y_true == 0).sum().item()
    num_1 = (y_true == 1).sum().item()
    if num_0 == 0 or num_1 == 0:
        return F.nll_loss(y_pred_log, y_true)

    total = num_0 + num_1
    w0 = total / (2.0 * num_0 + 1e-6)
    w1 = total / (2.0 * num_1 + 1e-6)
    weights = torch.tensor([w0, w1], dtype=torch.float32, device=y_pred_log.device)

    return F.nll_loss(y_pred_log, y_true, weight=weights)


def train_graphsage(
    model: nn.Module,
    graph_data,
    epochs: int = 200,
    learning_rate: float = 0.001,
    weight_decay: float = 5e-4,
):
    """
    Train GraphSAGE on graph_data.y (ignores -1).
    """
    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate, weight_decay=weight_decay)

    for epoch in range(epochs):
        model.train()
        optimizer.zero_grad()

        y_pred_log = model(graph_data)
        loss = graphsage_loss(y_pred_log, graph_data.y)

        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
        optimizer.step()

        if epoch % 10 == 0:
            num_labeled = (graph_data.y != -1).sum().item()
            print(f"[GraphSAGE Epoch {epoch}] Loss: {loss.item():.4f} | Using {num_labeled} labeled nodes")

    return model
