import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import SGConv


class SGCWithSegments(nn.Module):
    """
    Simplified Graph Convolution (SGC) baseline.

    - Uses SGConv (K-hop propagation + linear classifier)
    - Uses edge weights via graph_data.edge_attr if available
    - get_probabilities returns P(class=1)=normal (compatible with GCN evaluator)
    """

    def __init__(self, input_dim: int, output_dim: int = 2, K: int = 2, dropout: float = 0.0):
        super().__init__()
        self.dropout = dropout
        self.conv = SGConv(
            in_channels=input_dim,
            out_channels=output_dim,
            K=K,
            cached=False,
            add_self_loops=True
        )

    def forward(self, data):
        x = data.x
        edge_index = data.edge_index

        edge_weight = getattr(data, "edge_attr", None)
        if edge_weight is not None:
            if edge_weight.dim() > 1:
                edge_weight = edge_weight.view(-1)
            edge_weight = edge_weight.to(x.device)

        if self.dropout > 0:
            x = F.dropout(x, p=self.dropout, training=self.training)

        out = self.conv(x, edge_index, edge_weight=edge_weight)
        return F.log_softmax(out, dim=1)

    def get_probabilities(self, data):
        # P(class=1) = normal
        return torch.exp(self.forward(data))[:, 1]

    def predict(self, data):
        self.eval()
        with torch.no_grad():
            logits = self.forward(data)
            return torch.argmax(logits, dim=1)


def sgc_loss(y_pred_log, y_true):
    """
    Class-weighted NLL loss on labeled nodes only (y != -1).
    """
    mask = (y_true != -1)
    y_true = y_true[mask]
    y_pred_log = y_pred_log[mask]

    num_0 = (y_true == 0).sum().item()
    num_1 = (y_true == 1).sum().item()

    if num_0 == 0 or num_1 == 0:
        return F.nll_loss(y_pred_log, y_true)

    total = num_0 + num_1
    w0 = total / (2.0 * num_0 + 1e-6)
    w1 = total / (2.0 * num_1 + 1e-6)

    weights = torch.tensor([w0, w1], dtype=torch.float32, device=y_pred_log.device)
    return F.nll_loss(y_pred_log, y_true, weight=weights)


def train_sgc(
    model: nn.Module,
    graph_data,
    epochs: int = 200,
    learning_rate: float = 0.01,
    weight_decay: float = 5e-4
):
    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate, weight_decay=weight_decay)

    for epoch in range(epochs):
        model.train()
        optimizer.zero_grad()

        y_pred_log = model(graph_data)
        loss = sgc_loss(y_pred_log, graph_data.y)

        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
        optimizer.step()

        if epoch % 10 == 0:
            num_labeled = (graph_data.y != -1).sum().item()
            print(f"[SGC Epoch {epoch}] Loss: {loss.item():.4f} | Using {num_labeled} labeled nodes")

    return model
