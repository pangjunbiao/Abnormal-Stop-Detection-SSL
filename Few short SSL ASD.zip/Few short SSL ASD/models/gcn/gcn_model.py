import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import GCNConv
from sklearn.metrics import precision_score, recall_score, f1_score, accuracy_score, roc_auc_score, average_precision_score, roc_curve, precision_recall_curve
import matplotlib.pyplot as plt
import numpy as np

class GCNWithSegments(nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim=2, num_layers=3):
        super(GCNWithSegments, self).__init__()
        self.layers = nn.ModuleList()
        self.layers.append(GCNConv(input_dim, hidden_dim))

        for _ in range(num_layers - 2):
            self.layers.append(GCNConv(hidden_dim, hidden_dim))

        self.layers.append(GCNConv(hidden_dim, output_dim))

    def forward(self, data):
        x, edge_index, edge_weight = data.x, data.edge_index, data.edge_attr
        for i, layer in enumerate(self.layers):
            x = layer(x, edge_index, edge_weight=edge_weight)
            if i < len(self.layers) - 1:
                x = F.relu(x)
                x = F.dropout(x, p=0.5, training=self.training)
        return F.log_softmax(x, dim=1)

    def get_probabilities(self, data):
        return torch.exp(self.forward(data))[:, 1]  # Prob of class 1 (normal)

    def predict(self, data):
        self.eval()
        with torch.no_grad():
            logits = self.forward(data)
            return torch.argmax(logits, dim=1)

    def get_segment_predictions(self, data, segment_ids):
        probs = self.get_probabilities(data)
        segment_predictions = []
        for seg_id in torch.unique(segment_ids):
            mask = segment_ids == seg_id
            segment_predictions.append(probs[mask].mean().item())
        return segment_predictions

def gcn_loss_with_regularization(y_pred, y_true, edge_index, edge_attr, lambda1=0.001, lambda2=0.01):
    """
    Class-weighted loss + optional regularization for sparsity and temporal smoothness.
    """
    mask = y_true != -1
    y_true = y_true[mask]
    y_pred = y_pred[mask]

    # Handle label imbalance
    num_0 = (y_true == 0).sum().item()
    num_1 = (y_true == 1).sum().item()
    total = num_0 + num_1

    class_weights = torch.tensor([
        total / (2.0 * num_0 + 1e-6),
        total / (2.0 * num_1 + 1e-6)
    ], dtype=torch.float32, device=y_pred.device)

    loss = F.nll_loss(y_pred, y_true, weight=class_weights)

    # Regularization terms
    edge_attr = edge_attr / (edge_attr.max() + 1e-6)
    valid_mask = (edge_index[0] < edge_attr.size(0)) & (edge_index[1] < edge_attr.size(0))
    edge_index = edge_index[:, valid_mask]

    sparsity_loss = lambda1 * torch.sum(torch.abs(edge_attr))
    smoothness_loss = lambda2 * torch.sum((edge_attr[edge_index[0]] - edge_attr[edge_index[1]]) ** 2)

    return loss + sparsity_loss + smoothness_loss


def train_segment_aware_gcn(model, graph_data, segment_ids, epochs=200, learning_rate=0.001, lambda1=0.001, lambda2=0.01):
    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)

    for epoch in range(epochs):
        model.train()
        optimizer.zero_grad()
        y_pred = model(graph_data)

        loss = gcn_loss_with_regularization(y_pred, graph_data.y, graph_data.edge_index, graph_data.edge_attr, lambda1, lambda2)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
        optimizer.step()

        if epoch % 10 == 0:
            num_labeled = (graph_data.y != -1).sum().item()
            print(f"[Epoch {epoch}] Loss: {loss.item():.4f} | Using {num_labeled} labeled nodes")

    return model


def evaluate_gcn_predictions_ap_auc(
    model,
    graph_data,
    metrics_csv: str = None,
    trial_id: str = None,
    seed: int = None,
    setting: str = "GCN"
):
    import os, csv
    from datetime import datetime
    import numpy as np
    import torch
    from sklearn.metrics import (
        roc_auc_score, average_precision_score,
        roc_curve, precision_recall_curve
    )
    import matplotlib.pyplot as plt

    def _append_and_report(csv_path, trial_id, seed, setting, auc, ap):
        os.makedirs(os.path.dirname(csv_path), exist_ok=True)
        file_exists = os.path.isfile(csv_path)

        with open(csv_path, "a", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(
                f,
                fieldnames=["timestamp", "trial_id", "seed", "setting", "auc", "ap"]
            )
            if not file_exists:
                writer.writeheader()
            writer.writerow({
                "timestamp": datetime.now().isoformat(timespec="seconds"),
                "trial_id": trial_id if trial_id else (f"seed_{seed}" if seed is not None else ""),
                "seed": seed if seed is not None else "",
                "setting": setting,
                "auc": float(auc),
                "ap": float(ap),
            })

        # Read back and compute running mean±std for this setting
        aucs, aps = [], []
        with open(csv_path, "r", newline="", encoding="utf-8") as rf:
            reader = csv.DictReader(rf)
            for row in reader:
                if row.get("setting", "") == setting:
                    try:
                        aucs.append(float(row["auc"]))
                        aps.append(float(row["ap"]))
                    except Exception:
                        pass

        if len(aucs) >= 2:
            print(f"📌 Running summary for {setting} over {len(aucs)} trials:")
            print(f"  ➤ AUC (mean±std): {np.mean(aucs):.4f} ± {np.std(aucs, ddof=1):.4f}")
            print(f"  ➤ AP  (mean±std): {np.mean(aps):.4f} ± {np.std(aps, ddof=1):.4f}")
        else:
            print(f"📌 {setting} recorded. Need ≥2 trials to show mean±std (currently {len(aucs)}).")

    model.eval()
    with torch.no_grad():
        probs = model.get_probabilities(graph_data).cpu().numpy()  # P(class=1) i.e., normal
        y_true = graph_data.y.cpu().numpy()
        mask = (y_true != -1)

        y_true_masked = y_true[mask]
        probs_masked = probs[mask]

        # Balance classes for AP/AUC
        pos_idx = (y_true_masked == 1)
        neg_idx = (y_true_masked == 0)
        if pos_idx.sum() == 0 or neg_idx.sum() == 0:
            print("⚠️ Cannot compute metrics — only one class present.")
            return 0.0, 0.0

        min_size = int(min(pos_idx.sum(), neg_idx.sum()))
        balanced_idx = np.concatenate([
            np.random.choice(np.where(pos_idx)[0], min_size, replace=False),
            np.random.choice(np.where(neg_idx)[0], min_size, replace=False)
        ])

        balanced_y = y_true_masked[balanced_idx]
        balanced_probs = probs_masked[balanced_idx]

        auc = roc_auc_score(balanced_y, balanced_probs)
        ap = average_precision_score(balanced_y, balanced_probs)

    print("📊 GCN Prediction Evaluation (Balanced AP & AUC):")
    print(f"  ➤ AUC: {auc:.4f}")
    print(f"  ➤ AP:  {ap:.4f}")

    # Plot ROC and PR curves
    fpr, tpr, _ = roc_curve(balanced_y, balanced_probs)
    precision, recall, _ = precision_recall_curve(balanced_y, balanced_probs)

    fig, axs = plt.subplots(1, 2, figsize=(10, 4))

    axs[0].plot(fpr, tpr, lw=2, label=f"AUC = {auc:.2f}")
    axs[0].plot([0, 1], [0, 1], lw=1, linestyle="--")
    axs[0].set_title(f"ROC Curve: AUC={auc:.2f}")
    axs[0].set_xlabel("False Positive Rate")
    axs[0].set_ylabel("True Positive Rate")
    axs[0].legend(loc="lower right")
    axs[0].grid(True, linestyle="--", alpha=0.4)

    axs[1].step(recall, precision, where="post", alpha=0.8)
    axs[1].fill_between(recall, precision, step="post", alpha=0.3)
    axs[1].set_title(f"Precision-Recall curve: AP={ap:.2f}")
    axs[1].set_xlabel("Recall")
    axs[1].set_ylabel("Precision")
    axs[1].grid(True, linestyle="--", alpha=0.4)

    plt.tight_layout()
    plt.savefig("./data/results/GCN_roc_pr_curves.png")
    print("✅ ROC & PR curve saved at ./data/results/GCN_roc_pr_curves.png")

    # Optional: append and print running mean±std
    if metrics_csv is not None:
        _append_and_report(metrics_csv, trial_id, seed, setting, auc, ap)

    return float(auc), float(ap)

