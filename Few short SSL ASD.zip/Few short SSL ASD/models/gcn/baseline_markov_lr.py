import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F


class MarkovLogReg(nn.Module):
    """
    Probabilistic baseline:
      1) Logistic regression on segment features (emission probabilities)
      2) First-order Markov smoothing over the ordered segments (HMM-style)

    Labels assumed:
      y=1 -> normal
      y=0 -> abnormal
      y=-1 -> unlabeled

    Output probabilities follow your convention:
      get_probabilities() returns P(class=1)=normal
    """

    def __init__(self, input_dim: int, l2: float = 1e-3):
        super().__init__()
        self.linear = nn.Linear(input_dim, 2)  # logits for {0,1}
        self.l2 = l2

        # Markov transition matrix T[c_prev, c_curr]
        # Learned from labeled data in fit_transition(); default is near-identity.
        self.register_buffer("T", torch.tensor([[0.80, 0.20],
                                                [0.20, 0.80]], dtype=torch.float32))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # returns log-probabilities over classes
        logits = self.linear(x)
        return F.log_softmax(logits, dim=1)

    def emission_probs(self, x: torch.Tensor) -> torch.Tensor:
        # returns probabilities over classes
        return torch.exp(self.forward(x))  # [N,2]

    def get_probabilities(self, data) -> torch.Tensor:
        """
        For compatibility with your evaluator:
        returns P(class=1)=normal for each node/segment
        """
        probs = self.emission_probs(data.x)
        return probs[:, 1]

    @staticmethod
    def _class_weights(y_labeled: torch.Tensor) -> torch.Tensor:
        # class-weighting to handle imbalance on labeled subset
        num0 = (y_labeled == 0).sum().item()
        num1 = (y_labeled == 1).sum().item()
        if num0 == 0 or num1 == 0:
            return torch.tensor([1.0, 1.0], device=y_labeled.device)
        total = num0 + num1
        w0 = total / (2.0 * num0 + 1e-6)
        w1 = total / (2.0 * num1 + 1e-6)
        return torch.tensor([w0, w1], dtype=torch.float32, device=y_labeled.device)

    def fit_transition(self, y: torch.Tensor, order: np.ndarray, laplace: float = 1.0):
        """
        Estimate transition probabilities from labeled nodes along the order.
        Uses Laplace smoothing.
        """
        y_np = y.detach().cpu().numpy()
        counts = np.ones((2, 2), dtype=np.float64) * laplace  # Laplace

        # Count transitions where both are labeled
        for t in range(len(order) - 1):
            i = order[t]
            j = order[t + 1]
            yi, yj = y_np[i], y_np[j]
            if yi in (0, 1) and yj in (0, 1):
                counts[int(yi), int(yj)] += 1.0

        T = counts / counts.sum(axis=1, keepdims=True)
        self.T = torch.tensor(T, dtype=torch.float32, device=self.T.device)

    @torch.no_grad()
    def markov_smooth(self, probs: torch.Tensor, order: np.ndarray) -> torch.Tensor:
        """
        Forward-backward smoothing on a single long sequence defined by 'order'.
        probs: [N,2] emission probabilities for all nodes (unordered).
        Returns smoothed probs [N,2] aligned to original indices.
        """
        N = probs.size(0)
        device = probs.device
        T = self.T.to(device)  # [2,2]

        # Build ordered emissions
        e = probs[torch.tensor(order, device=device)]  # [L,2]
        L = e.size(0)

        # Forward
        alpha = torch.zeros((L, 2), device=device)
        alpha[0] = e[0] / (e[0].sum() + 1e-12)
        for t in range(1, L):
            alpha[t] = (alpha[t - 1] @ T) * e[t]
            alpha[t] = alpha[t] / (alpha[t].sum() + 1e-12)

        # Backward
        beta = torch.ones((L, 2), device=device)
        for t in range(L - 2, -1, -1):
            beta[t] = (T @ (e[t + 1] * beta[t + 1]))
            beta[t] = beta[t] / (beta[t].sum() + 1e-12)

        # Posterior
        post = alpha * beta
        post = post / (post.sum(dim=1, keepdim=True) + 1e-12)  # [L,2]

        # Scatter back to original indices
        out = probs.clone()
        out[torch.tensor(order, device=device)] = post
        return out


def train_markov_lr(
    model: MarkovLogReg,
    graph_data,
    order: np.ndarray,
    epochs: int = 300,
    lr: float = 0.01,
    weight_decay: float = 1e-4,
    verbose_every: int = 25
):
    """
    Train logistic regression on labeled nodes; then estimate transition matrix.
    """
    optimizer = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=weight_decay)

    x = graph_data.x
    y = graph_data.y

    labeled_mask = (y != -1)
    if labeled_mask.sum().item() < 2:
        print("⚠️ Not enough labeled nodes to train MarkovLogReg.")
        return model

    class_w = model._class_weights(y[labeled_mask])

    for ep in range(epochs):
        model.train()
        optimizer.zero_grad()

        logp = model.forward(x)  # [N,2]
        loss = F.nll_loss(logp[labeled_mask], y[labeled_mask], weight=class_w)

        # tiny L2 on weights (extra stability)
        l2 = 0.0
        for p in model.parameters():
            l2 = l2 + (p ** 2).sum()
        loss = loss + model.l2 * l2

        loss.backward()
        optimizer.step()

        if ep % verbose_every == 0:
            print(f"[MarkovLR Epoch {ep}] loss={loss.item():.4f} | labeled={labeled_mask.sum().item()}")

    # Estimate transition after training
    model.eval()
    model.fit_transition(y, order, laplace=1.0)
    return model


@torch.no_grad()
def evaluate_markov_lr_ap_auc(model: MarkovLogReg, graph_data, order: np.ndarray):
    """
    Balanced AUC/AP evaluation (same spirit as your GCN evaluator)
    Uses smoothed posterior probs as outputs.
    Returns auc, ap.
    """
    from sklearn.metrics import roc_auc_score, average_precision_score

    model.eval()
    probs = model.emission_probs(graph_data.x)  # [N,2]
    probs_sm = model.markov_smooth(probs, order)  # [N,2]

    # P(class=1)=normal as in your pipeline
    p1 = probs_sm[:, 1].detach().cpu().numpy()
    y = graph_data.y.detach().cpu().numpy()

    mask = (y != -1)
    y_m = y[mask]
    p1_m = p1[mask]

    pos = (y_m == 1)
    neg = (y_m == 0)
    if pos.sum() == 0 or neg.sum() == 0:
        print("⚠️ Cannot compute AUC/AP — only one class present.")
        return 0.0, 0.0

    # balance
    rng = np.random.default_rng(0)
    min_sz = int(min(pos.sum(), neg.sum()))
    pos_idx = rng.choice(np.where(pos)[0], min_sz, replace=False)
    neg_idx = rng.choice(np.where(neg)[0], min_sz, replace=False)
    idx = np.concatenate([pos_idx, neg_idx])

    y_b = y_m[idx]
    p1_b = p1_m[idx]

    auc = roc_auc_score(y_b, p1_b)
    ap = average_precision_score(y_b, p1_b)

    print("📊 MarkovLR (balanced) :")
    print(f"  ➤ AUC: {auc:.4f}")
    print(f"  ➤ AP:  {ap:.4f}")
    return float(auc), float(ap)


def build_order_from_segment_time(graph_data, t_seg: np.ndarray = None):
    """
    If you already have segment timestamps, pass them in as t_seg (len=N).
    Otherwise, falls back to natural index order.
    """
    n = graph_data.x.size(0)
    if t_seg is None or len(t_seg) != n:
        return np.arange(n, dtype=np.int64)
    return np.argsort(t_seg).astype(np.int64)
