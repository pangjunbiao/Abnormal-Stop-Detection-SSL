import torch
import torch.nn.functional as F
from matplotlib import pyplot as plt
from sklearn.metrics import roc_auc_score, average_precision_score, roc_curve, precision_recall_curve
import numpy as np


def run_self_training(model, graph_data, threshold=0.8, max_new_labels=180, balance_labels=True):
    """
    Perform self-training with controlled pseudo-label injection.
    """
    model.eval()
    with torch.no_grad():
        logits = model(graph_data)
        probs = F.softmax(logits, dim=1)
        confidence, pseudo_labels = torch.max(probs, dim=1)

    refined_labels = graph_data.y.clone()
    mask_unlabeled = refined_labels == -1
    confident_mask = (confidence > threshold) & mask_unlabeled

    # Indices of confident unlabeled nodes
    candidate_indices = torch.where(confident_mask)[0]

    if balance_labels:
        # Separate class-wise candidates
        class0_indices = candidate_indices[pseudo_labels[candidate_indices] == 0]
        class1_indices = candidate_indices[pseudo_labels[candidate_indices] == 1]

        max_per_class = max_new_labels // 2

        selected_0 = class0_indices[:max_per_class]
        selected_1 = class1_indices[:max_per_class]

        selected_indices = torch.cat([selected_0, selected_1])
    else:
        selected_indices = candidate_indices[:max_new_labels]

    # Apply the refined labels only to selected indices
    refined_labels[selected_indices] = pseudo_labels[selected_indices]
    graph_data.y = refined_labels

    print(f"🔄 Self-training applied: {len(selected_indices)} new pseudo-labels added.")
    if balance_labels:
        print(f"  ➤ Added class 0: {len(selected_0)} | class 1: {len(selected_1)}")

    return graph_data

def evaluate_and_plot_ST(
    model,
    graph_data,
    label: str,
    metrics_csv: str = None,
    trial_id: str = None,
    seed: int = None,
    setting: str = "GCN+ST"
):
    import os, csv
    from datetime import datetime
    import numpy as np
    import torch
    from sklearn.metrics import (
        roc_auc_score, average_precision_score,
        roc_curve, precision_recall_curve
    )
    import matplotlib.pyplot as plt

    def _append_and_report(csv_path, trial_id, seed, setting, auc, ap):
        os.makedirs(os.path.dirname(csv_path), exist_ok=True)
        file_exists = os.path.isfile(csv_path)

        with open(csv_path, "a", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(
                f,
                fieldnames=["timestamp", "trial_id", "seed", "setting", "auc", "ap"]
            )
            if not file_exists:
                writer.writeheader()
            writer.writerow({
                "timestamp": datetime.now().isoformat(timespec="seconds"),
                "trial_id": trial_id if trial_id else (f"seed_{seed}" if seed is not None else ""),
                "seed": seed if seed is not None else "",
                "setting": setting,
                "auc": float(auc),
                "ap": float(ap),
            })

        # Read back and compute running mean±std for this setting
        aucs, aps = [], []
        with open(csv_path, "r", newline="", encoding="utf-8") as rf:
            reader = csv.DictReader(rf)
            for row in reader:
                if row.get("setting", "") == setting:
                    try:
                        aucs.append(float(row["auc"]))
                        aps.append(float(row["ap"]))
                    except Exception:
                        pass

        if len(aucs) >= 2:
            print(f"📌 Running summary for {setting} over {len(aucs)} trials:")
            print(f"  ➤ AUC (mean±std): {np.mean(aucs):.4f} ± {np.std(aucs, ddof=1):.4f}")
            print(f"  ➤ AP  (mean±std): {np.mean(aps):.4f} ± {np.std(aps, ddof=1):.4f}")
        else:
            print(f"📌 {setting} recorded. Need ≥2 trials to show mean±std (currently {len(aucs)}).")

    model.eval()
    with torch.no_grad():
        probs = model.get_probabilities(graph_data).cpu().numpy()  # P(class=1) i.e., normal
        y_true = graph_data.y.cpu().numpy()
        mask = (y_true != -1)

        y_true_masked = y_true[mask]
        probs_masked = probs[mask]

        pos_idx = (y_true_masked == 1)
        neg_idx = (y_true_masked == 0)
        if pos_idx.sum() == 0 or neg_idx.sum() == 0:
            print("⚠️ Cannot compute metrics — only one class present.")
            return 0.0, 0.0

        min_size = int(min(pos_idx.sum(), neg_idx.sum()))
        balanced_idx = np.concatenate([
            np.random.choice(np.where(pos_idx)[0], min_size, replace=False),
            np.random.choice(np.where(neg_idx)[0], min_size, replace=False)
        ])

        balanced_y = y_true_masked[balanced_idx]
        balanced_probs = probs_masked[balanced_idx]

        auc = roc_auc_score(balanced_y, balanced_probs)
        ap = average_precision_score(balanced_y, balanced_probs)

    print(f"📊 {label} Evaluation (Balanced AP & AUC):")
    print(f"  ➤ AUC: {auc:.4f}")
    print(f"  ➤ AP:  {ap:.4f}")

    fpr, tpr, _ = roc_curve(balanced_y, balanced_probs)
    precision, recall, _ = precision_recall_curve(balanced_y, balanced_probs)

    fig, axs = plt.subplots(1, 2, figsize=(10, 4))

    axs[0].plot(fpr, tpr, lw=2, label=f"AUC = {auc:.2f}")
    axs[0].plot([0, 1], [0, 1], lw=1, linestyle="--")
    axs[0].set_title(f"ROC Curve: AUC={auc:.2f}")
    axs[0].set_xlabel("False Positive Rate")
    axs[0].set_ylabel("True Positive Rate")
    axs[0].legend(loc="lower right")
    axs[0].grid(True, linestyle="--", alpha=0.4)

    axs[1].step(recall, precision, where="post", alpha=0.8)
    axs[1].fill_between(recall, precision, step="post", alpha=0.3)
    axs[1].set_title(f"Precision-Recall curve: AP={ap:.2f}")
    axs[1].set_xlabel("Recall")
    axs[1].set_ylabel("Precision")
    axs[1].grid(True, linestyle="--", alpha=0.4)

    plt.tight_layout()
    plt.savefig("./data/results/ST_roc_pr_curves.png")
    print("✅ ROC & PR curve saved at ./data/results/ST_roc_pr_curves.png")

    # Optional: append and print running mean±std
    if metrics_csv is not None:
        _append_and_report(metrics_csv, trial_id, seed, setting, auc, ap)

    return float(auc), float(ap)
