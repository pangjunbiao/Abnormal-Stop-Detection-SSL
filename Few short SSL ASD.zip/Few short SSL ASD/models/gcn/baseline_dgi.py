# baseline_dgi.py
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import GCNConv


# -------------------------
# Utils
# -------------------------
def _get_edge_weight(data, device):
    edge_weight = getattr(data, "edge_attr", None)
    if edge_weight is not None:
        if edge_weight.dim() > 1:
            edge_weight = edge_weight.view(-1)
        edge_weight = edge_weight.to(device)
    return edge_weight


def _weighted_nll_loss_on_labeled(log_probs, y_true):
    """
    Class-weighted NLL loss on labeled nodes only (y != -1), consistent with your SGC baseline.
    Assumes class 1 = normal (as in your evaluator).
    """
    mask = (y_true != -1)
    y = y_true[mask]
    lp = log_probs[mask]

    num_0 = (y == 0).sum().item()
    num_1 = (y == 1).sum().item()
    if num_0 == 0 or num_1 == 0:
        return F.nll_loss(lp, y)

    total = num_0 + num_1
    w0 = total / (2.0 * num_0 + 1e-6)
    w1 = total / (2.0 * num_1 + 1e-6)
    weights = torch.tensor([w0, w1], dtype=torch.float32, device=lp.device)
    return F.nll_loss(lp, y, weight=weights)


# -------------------------
# Encoder (GCN)
# -------------------------
class GCNEncoder(nn.Module):
    """
    GCN encoder that returns node embeddings (no softmax).
    Uses edge_attr as edge_weight if present.
    """
    def __init__(self, input_dim: int, hidden_dim: int, num_layers: int = 2, dropout: float = 0.5):
        super().__init__()
        assert num_layers >= 2, "num_layers must be >= 2"

        self.dropout = dropout
        self.convs = nn.ModuleList()
        self.convs.append(GCNConv(input_dim, hidden_dim))

        for _ in range(num_layers - 1):
            self.convs.append(GCNConv(hidden_dim, hidden_dim))

    def forward(self, data):
        x = data.x
        edge_index = data.edge_index
        edge_weight = _get_edge_weight(data, x.device)

        for i, conv in enumerate(self.convs):
            x = conv(x, edge_index, edge_weight=edge_weight)
            # apply nonlinearity for all layers
            x = F.relu(x)
            x = F.dropout(x, p=self.dropout, training=self.training)
        return x  # [N, hidden_dim]


# -------------------------
# DGI Module
# -------------------------
class DGIDiscriminator(nn.Module):
    """
    DGI discriminator: scores (h_i, summary) via a bilinear map.
    """
    def __init__(self, hidden_dim: int):
        super().__init__()
        self.bilinear = nn.Bilinear(hidden_dim, hidden_dim, 1)

    def forward(self, h, s):
        # h: [N, d], s: [d]
        s_expand = s.unsqueeze(0).expand_as(h)  # [N, d]
        return self.bilinear(h, s_expand).squeeze(-1)  # [N]


class DGI(nn.Module):
    """
    Deep Graph Infomax pretraining model:
    - positive: real features
    - negative: shuffled features
    """
    def __init__(self, encoder: nn.Module, hidden_dim: int):
        super().__init__()
        self.encoder = encoder
        self.disc = DGIDiscriminator(hidden_dim)

    @staticmethod
    def _summary(h):
        # summary vector s = sigmoid(mean(h))
        return torch.sigmoid(h.mean(dim=0))

    def forward(self, data):
        # positive embeddings
        h_pos = self.encoder(data)  # [N, d]
        s = self._summary(h_pos)    # [d]

        # corruption: shuffle node features
        corrupt_data = data.clone()
        perm = torch.randperm(data.x.size(0), device=data.x.device)
        corrupt_data.x = data.x[perm]

        h_neg = self.encoder(corrupt_data)

        pos_logits = self.disc(h_pos, s)
        neg_logits = self.disc(h_neg, s)
        return pos_logits, neg_logits


def dgi_loss(pos_logits, neg_logits):
    """
    Binary cross-entropy with logits:
    positive should be 1, negative should be 0
    """
    lbl_pos = torch.ones_like(pos_logits)
    lbl_neg = torch.zeros_like(neg_logits)
    loss_pos = F.binary_cross_entropy_with_logits(pos_logits, lbl_pos)
    loss_neg = F.binary_cross_entropy_with_logits(neg_logits, lbl_neg)
    return loss_pos + loss_neg


# -------------------------
# Full baseline: Pretrain (DGI) + Finetune (Classifier)
# -------------------------
class DGI_GCN_Baseline(nn.Module):
    """
    After pretraining encoder with DGI, we attach a classifier head and finetune.
    Compatible with your evaluator: get_probabilities returns P(class=1)=normal.
    """
    def __init__(self, input_dim: int, hidden_dim: int, output_dim: int = 2, num_layers: int = 2, dropout: float = 0.5):
        super().__init__()
        self.encoder = GCNEncoder(input_dim, hidden_dim, num_layers=num_layers, dropout=dropout)
        self.classifier = nn.Linear(hidden_dim, output_dim)

    def forward(self, data):
        h = self.encoder(data)
        out = self.classifier(h)
        return F.log_softmax(out, dim=1)

    def get_probabilities(self, data):
        # P(class=1)=normal (same convention as your current evaluator)
        return torch.exp(self.forward(data))[:, 1]

    def predict(self, data):
        self.eval()
        with torch.no_grad():
            logits = self.forward(data)
            return torch.argmax(logits, dim=1)


def pretrain_dgi(encoder: nn.Module, graph_data, hidden_dim: int, epochs: int = 200, lr: float = 1e-3, weight_decay: float = 0.0):
    """
    Pretrain encoder with DGI (returns pretrained encoder state).
    """
    device = graph_data.x.device
    dgi_model = DGI(encoder, hidden_dim).to(device)
    opt = torch.optim.Adam(dgi_model.parameters(), lr=lr, weight_decay=weight_decay)

    for epoch in range(epochs):
        dgi_model.train()
        opt.zero_grad()
        pos_logits, neg_logits = dgi_model(graph_data)
        loss = dgi_loss(pos_logits, neg_logits)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(dgi_model.parameters(), max_norm=1.0)
        opt.step()

        if epoch % 10 == 0:
            print(f"[DGI Pretrain Epoch {epoch}] Loss: {loss.item():.4f}")

    # encoder weights are updated inside dgi_model.encoder
    return dgi_model.encoder


def finetune_dgi_gcn(
    model: DGI_GCN_Baseline,
    graph_data,
    epochs: int = 200,
    lr: float = 1e-3,
    weight_decay: float = 5e-4
):
    """
    Supervised finetuning on labeled nodes only (y != -1), class-weighted.
    """
    opt = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=weight_decay)

    for epoch in range(epochs):
        model.train()
        opt.zero_grad()

        log_probs = model(graph_data)
        loss = _weighted_nll_loss_on_labeled(log_probs, graph_data.y)

        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
        opt.step()

        if epoch % 10 == 0:
            num_labeled = (graph_data.y != -1).sum().item()
            print(f"[DGI-GCN Finetune Epoch {epoch}] Loss: {loss.item():.4f} | Using {num_labeled} labeled nodes")

    return model
