# plot_and_save_distances_groundtruth_predicted.py

import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

def haversine_distance(lat1, lon1, lat2, lon2):
    """
    Calculate the great-circle distance between two points on Earth (in meters).
    """
    R = 6371000  # Radius of Earth in meters
    phi1, phi2 = np.radians(lat1), np.radians(lat2)
    delta_phi = np.radians(lat2 - lat1)
    delta_lambda = np.radians(lon2 - lon1)

    a = np.sin(delta_phi / 2)**2 + np.cos(phi1) * np.cos(phi2) * np.sin(delta_lambda / 2)**2
    c = 2 * np.arctan2(np.sqrt(a), np.sqrt(1 - a))

    return R * c

def plot_and_save_distances(predicted_abnormal_csv, ground_truth_coords, save_plot_path="./data/results/abnormal_vs_groundtruth_overlay.png", save_distance_csv="./data/results/groundtruth_predicted_distances.csv"):
    """
    Plot predicted abnormal stops and ground-truth stops, calculate nearest distances, and save distances to CSV.

    Args:
        predicted_abnormal_csv: Path to predicted abnormal stops CSV (latitude, longitude).
        ground_truth_coords: List of (longitude, latitude) tuples for ground-truth stops.
        save_plot_path: Path to save the overlay plot.
        save_distance_csv: Path to save the calculated distances CSV.
    """

    # 1. Load predicted abnormal points
    predicted_df = pd.read_csv(predicted_abnormal_csv)

    # 2. Ground-truth points
    true_stops = np.array(ground_truth_coords)

    # 3. Plot
    plt.figure(figsize=(10, 8))

    # Predicted points
    plt.scatter(predicted_df['longitude'], predicted_df['latitude'],
                color='red', label='Predicted Abnormal Stops', alpha=0.7)

    # Ground-truth points
    plt.scatter(true_stops[:,0], true_stops[:,1],
                color='blue', marker='x', s=100, label='Ground Truth Stops')

    plt.title("Overlay: True Stops vs. Predicted Abnormal Stops")
    plt.xlabel("Longitude")
    plt.ylabel("Latitude")
    plt.legend()
    plt.grid(True, linestyle='--', alpha=0.6)
    plt.tight_layout()

    os.makedirs(os.path.dirname(save_plot_path), exist_ok=True)
    plt.savefig(save_plot_path)
    plt.show()

    print(f"✅ Overlay plot saved to: {save_plot_path}")

    # 4. Calculate distances
    distance_records = []
    for idx, (true_lon, true_lat) in enumerate(true_stops):
        min_distance = float('inf')
        nearest_pred = None
        for _, row in predicted_df.iterrows():
            pred_lat = row['latitude']
            pred_lon = row['longitude']
            dist = haversine_distance(true_lat, true_lon, pred_lat, pred_lon)
            if dist < min_distance:
                min_distance = dist
                nearest_pred = (pred_lat, pred_lon)
        distance_records.append({
            "ground_truth_latitude": true_lat,
            "ground_truth_longitude": true_lon,
            "nearest_predicted_latitude": nearest_pred[0],
            "nearest_predicted_longitude": nearest_pred[1],
            "distance_meters": round(min_distance, 2)
        })

    # Save distances
    distance_df = pd.DataFrame(distance_records)
    os.makedirs(os.path.dirname(save_distance_csv), exist_ok=True)
    distance_df.to_csv(save_distance_csv, index=False)

    print(f"✅ Distances saved to: {save_distance_csv}")

    # ✅ Add this to return stats
    mean_dist = distance_df["distance_meters"].mean()
    median_dist = distance_df["distance_meters"].median()

    return mean_dist, median_dist
