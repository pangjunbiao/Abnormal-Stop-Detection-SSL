import torch
import torch.nn.functional as F
from matplotlib import pyplot as plt
from sklearn.metrics import roc_auc_score, average_precision_score, roc_curve, precision_recall_curve
import numpy as np


def run_self_training(model, graph_data, threshold=0.8, max_new_labels=180, balance_labels=True):
    """
    Perform self-training with controlled pseudo-label injection.
    """
    model.eval()
    with torch.no_grad():
        logits = model(graph_data)
        probs = F.softmax(logits, dim=1)
        confidence, pseudo_labels = torch.max(probs, dim=1)

    refined_labels = graph_data.y.clone()
    mask_unlabeled = refined_labels == -1
    confident_mask = (confidence > threshold) & mask_unlabeled

    # Indices of confident unlabeled nodes
    candidate_indices = torch.where(confident_mask)[0]

    if balance_labels:
        # Separate class-wise candidates
        class0_indices = candidate_indices[pseudo_labels[candidate_indices] == 0]
        class1_indices = candidate_indices[pseudo_labels[candidate_indices] == 1]

        max_per_class = max_new_labels // 2

        selected_0 = class0_indices[:max_per_class]
        selected_1 = class1_indices[:max_per_class]

        selected_indices = torch.cat([selected_0, selected_1])
    else:
        selected_indices = candidate_indices[:max_new_labels]

    # Apply the refined labels only to selected indices
    refined_labels[selected_indices] = pseudo_labels[selected_indices]
    graph_data.y = refined_labels

    print(f"🔄 Self-training applied: {len(selected_indices)} new pseudo-labels added.")
    if balance_labels:
        print(f"  ➤ Added class 0: {len(selected_0)} | class 1: {len(selected_1)}")

    return graph_data

def evaluate_and_plot_ST(model, graph_data, label, trial_id=None, k=None, seed=None):
    model.eval()
    with torch.no_grad():
        probs = model.get_probabilities(graph_data).cpu().numpy()
        y_true = graph_data.y.cpu().numpy()
        mask = y_true != -1

        y_true_masked = y_true[mask]
        probs_masked = probs[mask]

        pos_idx = y_true_masked == 1
        neg_idx = y_true_masked == 0
        if pos_idx.sum() == 0 or neg_idx.sum() == 0:
            print("⚠️ Cannot compute metrics — only one class present.")
            return {"ST_AP": 0.0, "ST_AUC": 0.0}

        min_size = min(pos_idx.sum(), neg_idx.sum())
        rng = np.random.default_rng(seed)
        balanced_idx = np.concatenate([
            rng.choice(np.where(pos_idx)[0], min_size, replace=False),
            rng.choice(np.where(neg_idx)[0], min_size, replace=False)
        ])

        balanced_y = y_true_masked[balanced_idx]
        balanced_probs = probs_masked[balanced_idx]

        auc = roc_auc_score(balanced_y, balanced_probs)
        ap = average_precision_score(balanced_y, balanced_probs)

        print(f"📊 {label} Evaluation:")
        print(f"  ➤ AUC: {auc:.4f}")
        print(f"  ➤ AP:  {ap:.4f}")

        fpr, tpr, _ = roc_curve(balanced_y, balanced_probs)
        precision, recall, _ = precision_recall_curve(balanced_y, balanced_probs)

        fig, axs = plt.subplots(1, 2, figsize=(10, 4))

        axs[0].plot(fpr, tpr, color='darkorange', lw=2, label=f"AUC = {auc:.2f}")
        axs[0].plot([0, 1], [0, 1], color='navy', lw=1, linestyle='--')
        axs[0].set_title(f"ROC Curve: AUC={auc:.2f}")
        axs[0].set_xlabel("False Positive Rate")
        axs[0].set_ylabel("True Positive Rate")
        axs[0].legend(loc="lower right")
        axs[0].grid(True, linestyle='--', alpha=0.4)

        axs[1].step(recall, precision, where='post', color='mediumpurple', alpha=0.8)
        axs[1].fill_between(recall, precision, step='post', alpha=0.3, color='mediumpurple')
        axs[1].set_title(f"Precision-Recall curve: PR={ap:.2f}")
        axs[1].set_xlabel("Recall")
        axs[1].set_ylabel("Precision")
        axs[1].grid(True, linestyle='--', alpha=0.4)

        plt.tight_layout()

        # Construct output path
        if k is not None and trial_id is not None:
            fig_name = f"./data/results/ST_roc_pr_k{k}_trial{trial_id}.png"
        else:
            fig_name = "./data/results/ST_roc_pr_curves.png"

        plt.savefig(fig_name)
        print(f"✅ ROC & PR curve saved at {fig_name}")

        return {"ST_AUC": auc, "ST_AP": ap}

