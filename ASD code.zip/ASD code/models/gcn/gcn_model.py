import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import GCNConv
from sklearn.metrics import precision_score, recall_score, f1_score, accuracy_score, roc_auc_score, average_precision_score, roc_curve, precision_recall_curve
import matplotlib.pyplot as plt
import numpy as np

class GCNWithSegments(nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim=2, num_layers=3):
        super(GCNWithSegments, self).__init__()
        self.layers = nn.ModuleList()
        self.layers.append(GCNConv(input_dim, hidden_dim))

        for _ in range(num_layers - 2):
            self.layers.append(GCNConv(hidden_dim, hidden_dim))

        self.layers.append(GCNConv(hidden_dim, output_dim))

    def forward(self, data):
        x, edge_index, edge_weight = data.x, data.edge_index, data.edge_attr
        for i, layer in enumerate(self.layers):
            x = layer(x, edge_index, edge_weight=edge_weight)
            if i < len(self.layers) - 1:
                x = F.relu(x)
                x = F.dropout(x, p=0.5, training=self.training)
        return F.log_softmax(x, dim=1)

    def get_probabilities(self, data):
        return torch.exp(self.forward(data))[:, 1]  # Prob of class 1 (normal)

    def predict(self, data):
        self.eval()
        with torch.no_grad():
            logits = self.forward(data)
            return torch.argmax(logits, dim=1)

    def get_segment_predictions(self, data, segment_ids):
        probs = self.get_probabilities(data)
        segment_predictions = []
        for seg_id in torch.unique(segment_ids):
            mask = segment_ids == seg_id
            segment_predictions.append(probs[mask].mean().item())
        return segment_predictions

def gcn_loss_with_regularization(y_pred, y_true, edge_index, edge_attr, lambda1=0.001, lambda2=0.01):
    """
    Class-weighted loss + optional regularization for sparsity and temporal smoothness.
    """
    mask = y_true != -1
    y_true = y_true[mask]
    y_pred = y_pred[mask]

    # Handle label imbalance
    num_0 = (y_true == 0).sum().item()
    num_1 = (y_true == 1).sum().item()
    total = num_0 + num_1

    class_weights = torch.tensor([
        total / (2.0 * num_0 + 1e-6),
        total / (2.0 * num_1 + 1e-6)
    ], dtype=torch.float32, device=y_pred.device)

    loss = F.nll_loss(y_pred, y_true, weight=class_weights)

    # Regularization terms
    edge_attr = edge_attr / (edge_attr.max() + 1e-6)
    valid_mask = (edge_index[0] < edge_attr.size(0)) & (edge_index[1] < edge_attr.size(0))
    edge_index = edge_index[:, valid_mask]

    sparsity_loss = lambda1 * torch.sum(torch.abs(edge_attr))
    smoothness_loss = lambda2 * torch.sum((edge_attr[edge_index[0]] - edge_attr[edge_index[1]]) ** 2)

    return loss + sparsity_loss + smoothness_loss


def train_segment_aware_gcn(model, graph_data, segment_ids, epochs=200, learning_rate=0.001, lambda1=0.001, lambda2=0.01):
    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)

    for epoch in range(epochs):
        model.train()
        optimizer.zero_grad()
        y_pred = model(graph_data)

        loss = gcn_loss_with_regularization(y_pred, graph_data.y, graph_data.edge_index, graph_data.edge_attr, lambda1, lambda2)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
        optimizer.step()

        if epoch % 10 == 0:
            num_labeled = (graph_data.y != -1).sum().item()
            print(f"[Epoch {epoch}] Loss: {loss.item():.4f} | Using {num_labeled} labeled nodes")

    return model


def evaluate_gcn_predictions_ap_auc(model, graph_data):
    model.eval()
    with torch.no_grad():
        probs = model.get_probabilities(graph_data).cpu().numpy()
        y_true = graph_data.y.cpu().numpy()
        mask = y_true != -1

        y_true_masked = y_true[mask]
        probs_masked = probs[mask]

        # Balance classes for AP/AUC
        pos_idx = y_true_masked == 1
        neg_idx = y_true_masked == 0
        if pos_idx.sum() == 0 or neg_idx.sum() == 0:
            print("⚠️ Cannot compute metrics — only one class present.")
            return {"GCN_AP": 0.0, "GCN_AUC": 0.0}

        min_size = min(pos_idx.sum(), neg_idx.sum())
        balanced_idx = np.concatenate([
            np.random.choice(np.where(pos_idx)[0], min_size, replace=False),
            np.random.choice(np.where(neg_idx)[0], min_size, replace=False)
        ])

        balanced_y = y_true_masked[balanced_idx]
        balanced_probs = probs_masked[balanced_idx]

        auc = roc_auc_score(balanced_y, balanced_probs)
        ap = average_precision_score(balanced_y, balanced_probs)

    print("📊 GCN Prediction Evaluation (Balanced AP & AUC):")
    print(f"  ➤ AUC: {auc:.4f}")
    print(f"  ➤ AP:  {ap:.4f}")

    # Truncate function (to avoid rounding)
    def truncate(num, decimals=2):
        factor = 10.0 ** decimals
        return int(num * factor) / factor

    # Then use truncated auc and ap for display
    display_auc = truncate(auc, 2)
    display_ap = truncate(ap, 2)

    # Plot ROC and PR curves
    fpr, tpr, _ = roc_curve(balanced_y, balanced_probs)
    precision, recall, _ = precision_recall_curve(balanced_y, balanced_probs)

    fig, axs = plt.subplots(1, 2, figsize=(10, 4))

    axs[0].plot(fpr, tpr, color='darkorange', lw=2, label=f"AUC = {display_auc:.2f}")
    axs[0].plot([0, 1], [0, 1], color='navy', lw=1, linestyle='--')
    axs[0].set_title(f"ROC Curve: AUC={display_auc:.2f}")
    axs[0].set_xlabel("False Positive Rate")
    axs[0].set_ylabel("True Positive Rate")
    axs[0].legend(loc="lower right")
    axs[0].grid(True, linestyle='--', alpha=0.4)

    axs[1].step(recall, precision, where='post', color='mediumpurple', alpha=0.8)
    axs[1].fill_between(recall, precision, step='post', alpha=0.3, color='mediumpurple')
    axs[1].set_title(f"Precision-Recall curve: PR={display_ap:.2f}")
    axs[1].set_xlabel("Recall")
    axs[1].set_ylabel("Precision")
    axs[1].grid(True, linestyle='--', alpha=0.4)

    plt.tight_layout()
    plt.savefig("./data/results/GCN_roc_pr_curves.png")
    print("✅ ROC & PR curve saved at ./data/results/GCN_roc_pr_curves.png")

    return {"GCN_AP": ap, "GCN_AUC": auc}
