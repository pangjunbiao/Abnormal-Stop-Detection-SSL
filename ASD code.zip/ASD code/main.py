import torch
import os
import csv
import numpy as np
import random
import time
import statistics
from models.gcn.gcn_model import GCNWithSegments, train_segment_aware_gcn, evaluate_gcn_predictions_ap_auc
from models.gcn.self_training import run_self_training, evaluate_and_plot_ST
from utils.evaluate_indicators import evaluate_indicators
from models.graph.feature_embedding import embed_node_features, calculate_features, apply_confidence_weights
from models.graph.SAGE_segmentation import segment_road_by_distance_and_time, summarize_segments, segment_fixed_length
from models.graph.graph_utils import build_adaptive_graph, apply_ltiga_adjustment
from utils.data_preprocessing import preprocess_data
from utils.label_propagation import run_label_propagation
from utils.plot_abnormal_vs_groundtruth import plot_and_save_distances
from utils.save_abnormal_nodes_after_self_training import save_abnormal_nodes_after_self_training
from utils.segment_visualize import visualize_segment_summary
from utils.save_abnormal_stops import save_abnormal_stops_after_self_training
from utils.verify_abnormal_nodes_and_segments import verify_abnormal_nodes_and_segments
from visualizations.plot_distance_distribution import plot_matched_abnormal_stops_with_distances
from visualizations.plot_prediction_confidence_histogram import plot_prediction_confidence_histogram
from visualizations.plot_segment_abnormality import plot_segment_abnormality_scores
from collections import Counter
from visualizations.visualize_indicator_scores import plot_auc_ap_scores
from visualizations.visualize_label_performance import plot_label_sensitivity_curve


# #Function to set random seed
def set_random_seed(seed=42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

set_random_seed(42)

def select_confidence_based_gps_subset(true_gps_array, processed_data, k, confidence_scores=None, mode="all"):
    import numpy as np
    from sklearn.metrics.pairwise import euclidean_distances

    labels = processed_data["pseudo_label"].values
    gps_coords = processed_data[["longitude", "latitude"]].values
    distances = euclidean_distances(true_gps_array, gps_coords)
    label_counts = [0, 0]
    selected = []

    candidate_indices = np.arange(len(true_gps_array))

    if confidence_scores is not None and mode in ["high", "low"]:
        sorted_indices = np.argsort(confidence_scores)
        if mode == "high":
            candidate_indices = sorted_indices[::-1]  # descending
        elif mode == "low":
            candidate_indices = sorted_indices  # ascending

    for idx in candidate_indices:
        gps = true_gps_array[idx]
        nearest_idx = distances[idx].argmin()
        label = labels[nearest_idx]
        if label in [0, 1] and label_counts[label] == 0:
            selected.append(gps.tolist())
            label_counts[label] += 1
            if len(selected) == k:
                break

    if len(selected) < k:
        selected_set = [tuple(gps) for gps in selected]
        remaining = [i for i in range(len(true_gps_array)) if tuple(true_gps_array[i].tolist()) not in selected_set]
        np.random.shuffle(remaining)
        for i in remaining:
            selected.append(true_gps_array[i].tolist())
            if len(selected) == k:
                break

    return np.array(selected)

def main():

    full_true_GPS = np.array([
        [116.302661, 39.880903], [116.310097, 39.897319], [116.310297, 39.925278],
        [116.310304, 39.938717], [116.309811, 39.943409], [116.309557, 39.953169],
        [116.313866, 39.964449], [116.380633, 39.981016], [116.366219, 40.007226],
        [116.362843, 40.011537]
    ])

    raw_data_dir = "./data/raw_data"
    dummy_true_GPS = full_true_GPS
    dummy_processed_data = preprocess_data(
        raw_data_dir,
        "./data/processed_data/dummy_processed.csv",
        "./data/processed_data/dummy_skipped.csv",
        dummy_true_GPS
    )

    label_sizes = [5, 7, 10]
    performance_log = {}
    repeats_per_k = 5

    for k in label_sizes:
        print(f"\n===== Running {repeats_per_k} trials with {k} labeled GPS stops =====")
        aucs, aps = [], []

        # Create trial-level log file
        log_dir = "./data/results/logs"
        os.makedirs(log_dir, exist_ok=True)
        log_path = os.path.join(log_dir, f"label_k={k}.csv")

        with open(log_path, mode='w', newline='') as log_file:
            writer = csv.writer(log_file)
            writer.writerow([
                "trial_id", "auc", "ap", "pseudo_label_dist",
                "predicted_before_st", "predicted_after_st",
                "abnormal_nodes_saved", "abnormal_segments_saved",
                "mean_matching_distance_m", "median_matching_distance_m",
                "skipped_reason"
            ])

        for trial in range(repeats_per_k):
            print(f"\nTrial {trial + 1}/{repeats_per_k} for k={k}...")
            set_random_seed(42 + trial)

            # NOTE: You must compute node_confidence_array before this point
            true_GPS = select_confidence_based_gps_subset(
                true_gps_array=full_true_GPS,
                processed_data=dummy_processed_data,
                k=k,
                confidence_scores=None,
                mode="all"
            )

            # Define paths
            raw_data_dir = "./data/raw_data"
            processed_data_path = "./data/processed_data/processed_data.csv"
            skipped_data_path = "./data/processed_data/skipped_rows.csv"
            node_features_raw_path = "./data/processed_data/node_features_raw.csv"
            node_features_ltiga_path = "./data/processed_data/node_features_ltiga.csv"
            plot_output_dir = "./data/results"
            results_output_path = "./data/processed_data/segment_results.csv"
            output_path = "./data/results/abnormal_predictions.csv"
            output_path_abnormal = "./data/results/abnormal_segments_final.csv"
            output_path_abnormal_node = "./data/results/abnormal_nodes_after_st.csv"
            output_path_groundtruth_predicted_distances = "./data/results/groundtruth_predicted_distances.csv"

            use_sas = True
            use_ltiga = True
            apply_inverse_norm = True

            print("Loading and preprocessing raw GPS data...")
            processed_data = preprocess_data(raw_data_dir, processed_data_path, skipped_data_path, true_GPS)
            print("Processed data saved at:", processed_data_path)

            if use_sas:
                print("Segmenting road using Sparsity-Aware Segmentation (SAS)...")
                segmented_data = segment_road_by_distance_and_time(
                    processed_data, adaptive=True, alpha=1.0, beta=1.0
                )
            else:
                print("Segmenting road using Fixed-Length Segmentation...")
                segmented_data = segment_fixed_length(processed_data, fixed_length_km=2.0)

            print("Summarizing segments...")
            segment_summary = summarize_segments(segmented_data)

            label_counts = segmented_data['pseudo_label'].value_counts().sort_index()
            print("🔍 Pseudo-label distribution:")
            for label in [-1, 0, 1]:
                print(f"Label {label}: {label_counts.get(label, 0)}")

            segment_summary = segmented_data.groupby('segment_id').agg({
                'distance_from_start': lambda x: x.max() - x.min(),
                'stay_time': 'sum'
            }).rename(columns={
                'distance_from_start': 'segment_length_km',
                'stay_time': 'total_stop_duration_sec'
            }).reset_index()

            print("📊 Segment summary preview:")
            print(segment_summary.head())
            visualize_segment_summary(segment_summary, use_sas=use_sas)

            print("Calculating indicators BEFORE LTIGA (unweighted)...")
            before_ltiga_data = calculate_features(segmented_data.copy(), use_weighted_confidence=False)
            embed_node_features(before_ltiga_data, output_file_path=node_features_raw_path)

            print("🔍 Evaluating indicators BEFORE LTIGA...")
            evaluate_indicators(
                before_data=before_ltiga_data,
                after_data=None,
                true_labels=before_ltiga_data["pseudo_label"],
                use_weighted_confidence=False
            )

            plot_auc_ap_scores(
                data=before_ltiga_data,
                true_labels=before_ltiga_data["pseudo_label"],
                metrics=["TIS", "MSD", "TTA@k"],
                title_suffix="Before LTIGA",
                use_weighted=False,
                save_path=f"{plot_output_dir}/before_ltiga_auc_ap.png"
            )

            if use_ltiga:
                print(f"Applying LTIGA to smooth unweighted indicators (inverse_norm={apply_inverse_norm})...")
                after_ltiga_data = apply_ltiga_adjustment(
                    before_ltiga_data.copy(),
                    apply_inverse_norm=apply_inverse_norm
                )
                after_ltiga_data = apply_confidence_weights(after_ltiga_data)
                embed_node_features(after_ltiga_data, output_file_path=node_features_ltiga_path)

                print("🔍 Evaluating indicators AFTER LTIGA...")
                evaluate_indicators(
                    before_data=before_ltiga_data,
                    after_data=after_ltiga_data,
                    true_labels=after_ltiga_data["pseudo_label"],
                    use_weighted_confidence=True
                )

                plot_auc_ap_scores(
                    data=after_ltiga_data,
                    true_labels=after_ltiga_data["pseudo_label"],
                    metrics=["TIS", "MSD", "TTA@k"],
                    title_suffix="After LTIGA",
                    use_weighted=True,
                    save_path=f"{plot_output_dir}/after_ltiga_auc_ap.png"
                )
            else:
                print("⛔ LTIGA is skipped for ablation experiment.")
                after_ltiga_data = apply_confidence_weights(before_ltiga_data.copy())
                embed_node_features(after_ltiga_data, output_file_path=node_features_ltiga_path)

                print("🔍 Evaluating indicators AFTER confidence weighting (w/o LTIGA)...")
                evaluate_indicators(
                    before_data=before_ltiga_data,
                    after_data=after_ltiga_data,
                    true_labels=after_ltiga_data["pseudo_label"],
                    use_weighted_confidence=True
                )

                plot_auc_ap_scores(
                    data=after_ltiga_data,
                    true_labels=after_ltiga_data["pseudo_label"],
                    metrics=["TIS", "MSD", "TTA@k"],
                    title_suffix="After Confidence Only",
                    use_weighted=True,
                    save_path=f"{plot_output_dir}/after_conf_only_auc_ap.png"
                )

            print("Constructing the graph{}...".format(" (with LTIGA)" if use_ltiga else " (w/o LTIGA)"))
            graph_data = build_adaptive_graph(after_ltiga_data)
            print(f"\u2705 Graph constructed with {graph_data.x.size(0)} nodes and {graph_data.edge_index.size(1)} edges.")
            graph_data.original_y = graph_data.y.clone()

            print("🔁 Running label propagation...")
            refined_labels = run_label_propagation(graph_data)
            graph_data.y = refined_labels
            graph_data.x = torch.nan_to_num(graph_data.x, nan=0.0, posinf=1.0, neginf=-1.0)

            print("Initializing and training the GCN model...")
            input_dim = graph_data.x.size(1)
            hidden_dim = 64
            output_dim = 2
            segment_ids = graph_data.segment_id

            model = GCNWithSegments(input_dim=input_dim, hidden_dim=hidden_dim, output_dim=output_dim, num_layers=3)
            trained_model = train_segment_aware_gcn(
                model, graph_data, segment_ids,
                epochs=300, learning_rate=0.001, lambda1=0.0005, lambda2=0.0005
            )

            probs = trained_model.get_probabilities(graph_data)
            predictions = (probs >= 0.26).long().cpu().numpy()
            print("GCN predicted label counts:", Counter(predictions))

            # verify_abnormal_nodes_and_segments(graph_data, probs=probs, threshold=0.26)
            abn_nodes, abn_segs = verify_abnormal_nodes_and_segments(graph_data, probs=probs, threshold=0.26)

            graph_data = run_self_training(model, graph_data, threshold=0.775, max_new_labels=180, balance_labels=True)

            print("Retraining the GCN on propagated labels...")
            model = GCNWithSegments(input_dim=input_dim, hidden_dim=hidden_dim, output_dim=output_dim)
            trained_model = train_segment_aware_gcn(
                model, graph_data, segment_ids,
                epochs=230, learning_rate=0.001, lambda1=0.001, lambda2=0.001
            )

            print("Retraining completed.")
            probs = trained_model.get_probabilities(graph_data)
            predictions = (probs >= 0.26).long().cpu().numpy()
            print("ST predicted label counts:", Counter(predictions))

            print("Evaluating GCN performance after self-training...")
            results_after_self_training = evaluate_and_plot_ST(
                trained_model,
                graph_data,
                label=f"GCN + Self-Training ({k} labels, Trial {trial + 1})",
                trial_id=trial + 1,
                k=k,
                seed=42 + trial  # Ensures reproducibility
            )
            auc = results_after_self_training["ST_AUC"]
            ap = results_after_self_training["ST_AP"]
            print(f"AUC after self-training: {auc}")
            print(f"AP after self-training: {ap}")

            # ✅ Store for summary statistics later
            aucs.append(auc)
            aps.append(ap)

            # ✅ Step 1: Define the missing variables
            dist_summary_here = label_counts.to_dict()
            pred_before_st = dict(Counter(graph_data.original_y.cpu().numpy()))
            pred_after_st = dict(Counter(graph_data.y.cpu().numpy()))
            abn_nodes, abn_segs = verify_abnormal_nodes_and_segments(graph_data, probs=probs, threshold=0.26)
            abn_nodes = int(abn_nodes)
            abn_segs = int(abn_segs)


            plot_segment_abnormality_scores(trained_model, graph_data, segment_ids, top_n=160)

            # verify_abnormal_nodes_and_segments(graph_data, probs=probs, threshold=0.26)

            abn_segs = save_abnormal_stops_after_self_training(
                model=trained_model,
                graph_data=graph_data,
                segmented_data_with_gps=after_ltiga_data,
                output_path=output_path_abnormal,
                threshold=0.26
            )

            abn_nodes = save_abnormal_nodes_after_self_training(
                model=trained_model,
                graph_data=graph_data,
                output_path=output_path_abnormal_node,
                threshold=0.26
            )

            trial_plot_path = f"./data/results/fig3_overlays/k={k}/overlay_trial={trial+1}.png"
            os.makedirs(os.path.dirname(trial_plot_path), exist_ok=True)

            mean_dist, median_dist = plot_and_save_distances(
                predicted_abnormal_csv=output_path_abnormal,
                ground_truth_coords=true_GPS,
                save_plot_path=trial_plot_path,
                save_distance_csv=output_path_groundtruth_predicted_distances
            )

            plot_matched_abnormal_stops_with_distances(
                predicted_csv=output_path_abnormal,
                true_gps_array=true_GPS,
                save_path="./data/results/matched_stops_with_distances.png"
            )

            # ✅ Step 2: Write the log (append mode)
            with open(log_path, mode='a', newline='') as log_file:
                writer = csv.writer(log_file)
                writer.writerow([
                    trial + 1,
                    round(auc, 4), round(ap, 4),
                    str(dist_summary_here),
                    str(pred_before_st), str(pred_after_st),
                    abn_nodes, abn_segs,
                    round(mean_dist, 2), round(median_dist, 2),
                    "OK"
                ])

            plot_prediction_confidence_histogram(trained_model, graph_data)

            # After all trials for this k are completed
        mean_auc = round(statistics.mean(aucs), 4)
        mean_ap = round(statistics.mean(aps), 4)
        std_auc = round(statistics.stdev(aucs), 4)
        std_ap = round(statistics.stdev(aps), 4)

        performance_log[f"{k}_labels"] = {
            "ST_AUC": mean_auc,
            "ST_AP": mean_ap,
            "std_auc": std_auc,
            "std_ap": std_ap
        }

        # Save to CSV
        csv_save_path = "./data/results/label_sensitivity_summary.csv"
        file_mode = 'w' if k == label_sizes[0] else 'a'

        with open(csv_save_path, mode=file_mode, newline='') as file:
            writer = csv.writer(file)
            if file_mode == 'w':
                writer.writerow(["label_count", "mean_auc", "std_auc", "mean_ap", "std_ap"])
            writer.writerow([k, mean_auc, std_auc, mean_ap, std_ap])

        # Final summary after all label sizes
    print("\n📊 Summary of label sensitivity experiment:")
    for label_count, metrics in performance_log.items():
        print(f"{label_count}: "
              f"Mean AUC = {metrics['ST_AUC']:.4f}, "
              f"Std AUC = {metrics['std_auc']:.4f}, "
              f"Mean AP = {metrics['ST_AP']:.4f}, "
              f"Std AP = {metrics['std_ap']:.4f}")

    # ✅ Plot the label sensitivity curve after all runs
    plot_label_sensitivity_curve()


if __name__ == "__main__":
    main()
