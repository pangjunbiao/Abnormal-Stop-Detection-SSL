# plot_matched_abnormal_stops_with_distances_fixed.py

import os
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from geopy.distance import geodesic

def plot_matched_abnormal_stops_with_distances(predicted_csv, true_gps_array, save_path="./data/results/matched_stops_with_distances.png"):
    """
    Plot predicted abnormal stops vs ground-truth stops (from memory array), draw matched pairs, and annotate distances.

    Args:
        predicted_csv: Path to CSV file containing predicted abnormal stops (segment_id, latitude, longitude)
        true_gps_array: Numpy array of true ground-truth GPS stops [[lon1, lat1], [lon2, lat2], ...]
        save_path: Where to save the plot
    """

    # 1. Load predicted abnormal stops
    pred = pd.read_csv(predicted_csv)
    pred_coords = pred[['latitude', 'longitude']].values

    # 2. True ground-truth stops (directly from memory, no CSV)
    gt_coords = np.array(true_gps_array)

    # 3. Match each ground-truth stop to nearest predicted stop
    matched_pred_indices = []
    distances = []

    for gt_point in gt_coords:
        min_dist = float('inf')
        min_idx = -1
        for i, pred_point in enumerate(pred_coords):
            dist = geodesic((gt_point[1], gt_point[0]), (pred_point[0], pred_point[1])).meters
            if dist < min_dist:
                min_dist = dist
                min_idx = i
        matched_pred_indices.append(min_idx)
        distances.append(min_dist)

    # 4. Plot
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    plt.figure(figsize=(10, 8))

    # Plot predicted abnormal stops
    plt.scatter(pred_coords[:, 1], pred_coords[:, 0], color='red', label='Predicted Abnormal Stops', s=40, alpha=0.8, edgecolor='black')

    # Plot ground-truth abnormal stops
    plt.scatter(gt_coords[:, 0], gt_coords[:, 1], color='blue', label='Ground Truth Stops', marker='x', s=60, linewidth=2)

    # Draw lines and annotate distances
    for i, gt_point in enumerate(gt_coords):
        pred_idx = matched_pred_indices[i]
        pred_point = pred_coords[pred_idx]

        plt.plot([gt_point[0], pred_point[1]], [gt_point[1], pred_point[0]], color='gray', linestyle='--', alpha=0.7)

        # Annotate distance
        mid_lon = (gt_point[0] + pred_point[1]) / 2
        mid_lat = (gt_point[1] + pred_point[0]) / 2
        plt.text(mid_lon, mid_lat, f"{distances[i]/1000:.2f} km", fontsize=9, color='green', ha='center')

    plt.title("Overlay of Ground Truth and Predicted Abnormal Stops with Distances", fontsize=15)
    plt.xlabel("Longitude", fontsize=12)
    plt.ylabel("Latitude", fontsize=12)
    plt.legend()
    plt.grid(True, linestyle='--', alpha=0.4)
    plt.tight_layout()
    plt.savefig(save_path)
    plt.show()

    print(f"✅ Matched abnormal stops plot saved at: {save_path}")
    print(f"📊 Mean Matching Distance: {np.mean(distances)/1000:.2f} km")
    print(f"📊 Median Matching Distance: {np.median(distances)/1000:.2f} km")
