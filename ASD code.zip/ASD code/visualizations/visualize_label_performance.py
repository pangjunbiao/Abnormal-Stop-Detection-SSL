import pandas as pd
import matplotlib.pyplot as plt

def plot_label_sensitivity_curve():
    df = pd.read_csv('./data/results/label_sensitivity_summary.csv')
    df = df.sort_values(by='label_count')

    plt.figure(figsize=(8, 6))
    plt.plot(df['label_count'], df['mean_auc'], label='AUC', marker='o')
    plt.plot(df['label_count'], df['mean_ap'], label='AP', marker='s')
    plt.xlabel('Number of Labeled GPS Stops')
    plt.ylabel('Score')
    plt.title('Label Sensitivity Experiment (Mean Performance)')
    plt.xticks(df['label_count'].tolist())  # x-axis = label sizes
    plt.grid(True)
    plt.legend()
    plt.tight_layout()
    plt.savefig('./data/results/label_sensitivity_plot.png', dpi=300)
    plt.show()
