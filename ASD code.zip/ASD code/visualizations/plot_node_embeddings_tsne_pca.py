# plot_node_embeddings_tsne_pca_corrected.py

import os
import matplotlib.pyplot as plt
import torch
from sklearn.manifold import TSNE
from collections import Counter


def plot_node_embeddings_tsne_pca(model, graph_data, method="tsne",
                                  output_path="./data/results/node_embedding_plot.png"):
    """
    Visualize node embeddings from the GCN model using t-SNE in 2D.
    Color-code points by predicted label (0 = abnormal, 1 = normal).

    Args:
        model: Trained GCN model.
        graph_data: PyG Data object (graph with x, edge_index, edge_attr).
        method: "tsne" (default) or "pca" if PCA reduction is added later.
        output_path: File path to save the plot.
    """

    model.eval()
    with torch.no_grad():
        # 1. Get node embeddings (before last layer)
        x = graph_data.x
        edge_index = graph_data.edge_index
        edge_weight = graph_data.edge_attr

        for i, layer in enumerate(model.layers[:-1]):  # Apply all layers except last
            x = layer(x, edge_index, edge_weight=edge_weight)
            x = torch.relu(x)

        embeddings = x.cpu().numpy()

        # 2. Get predicted labels
        probs = model.get_probabilities(graph_data).cpu()
        predictions = (probs >= 0.26).long().numpy()  # Using same threshold you used for saving abnormal
        print("✅ Predicted label counts:", Counter(predictions))

    # 3. Dimensionality reduction
    if method.lower() == "tsne":
        reducer = TSNE(n_components=2, random_state=42, perplexity=30)
        reduced = reducer.fit_transform(embeddings)
    else:
        raise ValueError(f"Unsupported reduction method: {method}")

    # 4. Prepare masks
    abnormal_mask = predictions == 0
    normal_mask = predictions == 1

    # 5. Plot
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    plt.figure(figsize=(9, 7))

    # Normal nodes
    plt.scatter(
        reduced[normal_mask, 0], reduced[normal_mask, 1],
        color='royalblue', label='Normal (1)', s=40, alpha=0.85, edgecolor='black', linewidth=0.3
    )

    # Abnormal nodes
    plt.scatter(
        reduced[abnormal_mask, 0], reduced[abnormal_mask, 1],
        color='crimson', label='Abnormal (0)', s=40, alpha=0.85, edgecolor='black', linewidth=0.3
    )

    plt.title(f"2D Node Embedding Visualization ({method.upper()})", fontsize=14)
    plt.xlabel("Latent Dimension 1", fontsize=12)
    plt.ylabel("Latent Dimension 2", fontsize=12)
    plt.grid(True, linestyle='--', alpha=0.4)
    plt.legend(loc='upper right', title="Predicted Label")
    plt.tight_layout()

    plt.savefig(output_path)
    plt.show()

    print(f"✅ Node embedding {method.upper()} plot saved at: {output_path}")
