# File: visualize_abnormal_vs_true_stops.py

import os
import matplotlib.pyplot as plt
import pandas as pd
import torch

def visualize_abnormal_vs_true_stops(graph_data, segmented_data_with_gps, true_gps, output_dir="./data/results"):
    """
    Overlay GCN-predicted abnormal stops with true stop GPS coordinates.
    """
    os.makedirs(output_dir, exist_ok=True)

    # Step 1: Attach predicted labels
    predicted_labels = graph_data.y.cpu().numpy()
    segmented_data_with_gps = segmented_data_with_gps.copy()
    segmented_data_with_gps["predicted_label"] = predicted_labels[segmented_data_with_gps["segment_id"].values]

    # Step 2: Extract predicted abnormal stops
    predicted_abnormals = segmented_data_with_gps[segmented_data_with_gps["predicted_label"] == 0]
    print(f"✅ Total predicted abnormal points: {len(predicted_abnormals)}")  # PRINT ON CONSOLE

    # Step 3: Prepare true stop GPS DataFrame
    true_df = pd.DataFrame(true_gps, columns=["longitude", "latitude"])

    # Step 4: Plot
    plt.figure(figsize=(8, 6))
    plt.scatter(predicted_abnormals["longitude"], predicted_abnormals["latitude"],
                c="red", alpha=0.7, edgecolor="black", label="Predicted Abnormal Stops")

    plt.scatter(true_df["longitude"], true_df["latitude"],
                c="blue", marker="x", s=100, label="True Stop Locations")

    plt.title("Overlay: True Stops vs. Predicted Abnormal Stops")
    plt.xlabel("Longitude")
    plt.ylabel("Latitude")
    plt.grid(True, linestyle="--", alpha=0.5)
    plt.legend()
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, "true_vs_predicted_abnormal_stops.png"))
    print(f"✅ Overlay plot saved at: {output_dir}/true_vs_predicted_abnormal_stops.png")
