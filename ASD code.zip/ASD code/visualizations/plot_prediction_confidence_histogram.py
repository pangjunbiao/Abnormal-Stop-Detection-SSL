# visualizations/plot_prediction_confidence_histogram.py

import os
import matplotlib.pyplot as plt
import torch

def plot_prediction_confidence_histogram(
    model,
    graph_data,
    bins=20,
    output_path="./data/results/confidence_histogram.png"
):
    """
    Plot a histogram of predicted probabilities for the abnormal class (class 1).

    Args:
        model: Trained GCN model with a get_probabilities method.
        graph_data: Graph data object containing the node features and structure.
        bins: Number of bins to use in the histogram.
        output_path: Where to save the histogram image.
    """

    model.eval()
    with torch.no_grad():
        probs = model.get_probabilities(graph_data).cpu().numpy()

    # Ensure directory exists
    os.makedirs(os.path.dirname(output_path), exist_ok=True)

    # Plot
    plt.figure(figsize=(8, 6))
    plt.hist(probs, bins=bins, color='skyblue', edgecolor='black', alpha=0.8)
    plt.title("Prediction Confidence Histogram", fontsize=14)
    plt.xlabel("Predicted Probability (Class 1)", fontsize=12)
    plt.ylabel("Number of Nodes", fontsize=12)
    plt.grid(True, linestyle='--', alpha=0.5)
    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()

    print(f"✅ Confidence histogram saved at {output_path}")


# import matplotlib.pyplot as plt
# import torch
#
#
# def plot_prediction_confidence_histogram(model, graph_data, bins=20, output_path="./data/results/confidence_histogram.png"):
#     """
#     Plot a histogram of predicted probabilities for the abnormal class (class 1).
#
#     Args:
#         model: Trained GCN model with a get_probabilities method.
#         graph_data: Graph data object containing the node features and structure.
#         bins: Number of bins to use in the histogram.
#         output_path: Where to save the histogram image.
#     """
#     model.eval()
#     with torch.no_grad():
#         probs = model.get_probabilities(graph_data).cpu().numpy()
#
#     plt.figure(figsize=(8, 6))
#     plt.hist(probs, bins=bins, color='skyblue', edgecolor='black')
#     plt.title("Prediction Confidence Histogram (Class 1 Probability)")
#     plt.xlabel("Predicted Probability")
#     plt.ylabel("Node Count")
#     plt.grid(True, linestyle='--', alpha=0.5)
#     plt.tight_layout()
#     plt.savefig(output_path)
#     plt.close()
#     print(f"✅ Confidence histogram saved at {output_path}")
